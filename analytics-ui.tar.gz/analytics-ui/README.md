# Analytics Agent — Angular UI

A terminal-dark frontend for the LangGraph analytics agent backend.

## Stack

- **Angular 17** · standalone components, signals-ready
- **SCSS** with CSS custom properties design tokens
- **HttpClient** → FastAPI `/api/v1/ask`
- **Proxy** → dev server forwards `/api` to `localhost:8000`

## Project structure

```
src/app/
├── components/
│   ├── chat/            # Main conversation shell
│   ├── header/          # Brand bar + API status indicator
│   └── steps-panel/     # Collapsible plan → SQL → Python → answer trace
├── models/
│   └── api.models.ts    # AskRequest, AskResponse, ChatMessage, Step
└── services/
    └── analytics.service.ts  # HttpClient wrapper for /api/v1/ask
```

## Getting started

```bash
# 1. Install dependencies
npm install

# 2. Start the FastAPI backend (in the project/ directory)
cd ../project
OPENAI_API_KEY=sk-... python main.py

# 3. Start the Angular dev server (proxy forwards /api → localhost:8000)
cd ../analytics-ui
npm start
# → http://localhost:4200
```

## Changing the API URL

Edit `src/environments/environment.ts`:

```ts
export const environment = {
  production: false,
  apiUrl: 'http://your-host:8000',
};
```

## Features

- **Natural language input** — Enter to send, Shift+Enter for newline
- **Typing indicator** while the agent reasons
- **Collapsible reasoning trace** — click "N steps" to expand plan/SQL/Python/answer steps
- **SQL row counts** displayed inline
- **API health badge** — live dot in the header
- **Suggestion chips** on empty state to get started fast
- **Session continuity** — session ID persists until "Clear chat" is pressed
- **Auto-growing textarea** — expands with content up to 160px
- **Error states** — shown inline in the assistant bubble

## Production build

```bash
npm run build
# Output: dist/analytics-ui/
# Serve with nginx or any static host; set apiUrl to your backend origin.
```
