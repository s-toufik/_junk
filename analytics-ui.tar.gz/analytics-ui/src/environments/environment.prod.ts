export const environment = {
  production: true,
  apiUrl: '', // Set via proxy or same-origin in production
};
