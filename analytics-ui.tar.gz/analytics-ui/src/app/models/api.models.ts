export interface AskRequest {
  question: string;
  session_id?: string;
}

export interface Step {
  step_type: 'plan' | 'sql' | 'python' | 'answer';
  input: string;
  output: string;
}

export interface AskResponse {
  question: string;
  answer: string;
  steps: Step[];
  sql_row_counts: number[];
  python_outputs: string[];
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  response?: AskResponse;
  loading?: boolean;
  error?: string;
}
