import {
  Component, OnInit, AfterViewChecked,
  ViewChild, ElementRef, ChangeDetectorRef,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AnalyticsService } from '../../services/analytics.service';
import { ChatMessage } from '../../models/api.models';
import { StepsPanelComponent } from '../steps-panel/steps-panel.component';
import { HeaderComponent } from '../header/header.component';

const SUGGESTIONS = [
  'Which product generated the most revenue?',
  'Show total sales by region',
  'Which ticker had the highest total trade value?',
  'How many trades were made per month?',
  'Compare Widget A vs Widget B revenue',
];

@Component({
  selector: 'app-chat',
  standalone: true,
  imports: [CommonModule, FormsModule, HttpClientModule, StepsPanelComponent, HeaderComponent],
  templateUrl: './chat.component.html',
  styleUrls: ['./chat.component.scss'],
  providers: [AnalyticsService],
})
export class ChatComponent implements OnInit, AfterViewChecked {
  @ViewChild('scrollAnchor') private scrollAnchor!: ElementRef;
  @ViewChild('inputEl') private inputEl!: ElementRef<HTMLTextAreaElement>;

  messages: ChatMessage[] = [];
  draft = '';
  loading = false;
  apiOnline: boolean | null = null;
  suggestions = SUGGESTIONS;
  sessionId = crypto.randomUUID();
  expandedSteps: Set<string> = new Set();
  private shouldScroll = false;

  constructor(
    private analytics: AnalyticsService,
    private cdr: ChangeDetectorRef,
  ) {}

  ngOnInit(): void {
    this.analytics.health().subscribe({
      next: () => (this.apiOnline = true),
      error: () => (this.apiOnline = false),
    });
  }

  ngAfterViewChecked(): void {
    if (this.shouldScroll) {
      this.scrollAnchor?.nativeElement.scrollIntoView({ behavior: 'smooth' });
      this.shouldScroll = false;
    }
  }

  send(text?: string): void {
    const question = (text ?? this.draft).trim();
    if (!question || this.loading) return;

    this.draft = '';
    this.loading = true;
    this.shouldScroll = true;

    const userMsg: ChatMessage = {
      id: crypto.randomUUID(),
      role: 'user',
      content: question,
      timestamp: new Date(),
    };

    const assistantMsg: ChatMessage = {
      id: crypto.randomUUID(),
      role: 'assistant',
      content: '',
      timestamp: new Date(),
      loading: true,
    };

    this.messages.push(userMsg, assistantMsg);
    this.shouldScroll = true;

    this.analytics.ask(question, this.sessionId).subscribe({
      next: (res) => {
        assistantMsg.loading = false;
        assistantMsg.content = res.answer;
        assistantMsg.response = res;
        this.loading = false;
        this.shouldScroll = true;
        this.cdr.detectChanges();
        setTimeout(() => this.inputEl?.nativeElement.focus(), 50);
      },
      error: (err: Error) => {
        assistantMsg.loading = false;
        assistantMsg.error = err.message;
        assistantMsg.content = '';
        this.loading = false;
        this.shouldScroll = true;
        this.cdr.detectChanges();
      },
    });
  }

  toggleSteps(id: string): void {
    this.expandedSteps.has(id)
      ? this.expandedSteps.delete(id)
      : this.expandedSteps.add(id);
  }

  isExpanded(id: string): boolean {
    return this.expandedSteps.has(id);
  }

  onKeydown(e: KeyboardEvent): void {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      this.send();
    }
  }

  autoGrow(el: HTMLTextAreaElement): void {
    el.style.height = 'auto';
    el.style.height = Math.min(el.scrollHeight, 160) + 'px';
  }

  clearChat(): void {
    this.messages = [];
    this.sessionId = crypto.randomUUID();
  }

  trackById(_: number, m: ChatMessage): string { return m.id; }
}
