import { Component, Input, OnChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Step, AskResponse } from '../../models/api.models';

interface EnrichedStep extends Step {
  label: string;
  icon: string;
  colorClass: string;
  detail: string;
}

@Component({
  selector: 'app-steps-panel',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './steps-panel.component.html',
  styleUrls: ['./steps-panel.component.scss'],
})
export class StepsPanelComponent implements OnChanges {
  @Input() response: AskResponse | undefined;
  enriched: EnrichedStep[] = [];

  ngOnChanges(): void {
    if (!this.response) { this.enriched = []; return; }
    this.enriched = this.response.steps.map((s, i) => this.enrich(s, i));
  }

  private enrich(s: Step, idx: number): EnrichedStep {
    const map: Record<string, { label: string; icon: string; colorClass: string }> = {
      plan:   { label: 'Plan',    icon: '◈', colorClass: 'step--plan'   },
      sql:    { label: 'SQL',     icon: '⬡', colorClass: 'step--sql'    },
      python: { label: 'Python',  icon: '⬟', colorClass: 'step--python' },
      answer: { label: 'Answer',  icon: '◉', colorClass: 'step--answer' },
    };
    const meta = map[s.step_type] ?? { label: s.step_type, icon: '○', colorClass: '' };

    let detail = s.output;
    if (s.step_type === 'sql' && this.response!.sql_row_counts[this.sqlIndex(idx)] !== undefined) {
      const count = this.response!.sql_row_counts[this.sqlIndex(idx)];
      detail = `${count} row${count !== 1 ? 's' : ''} returned`;
    }

    return { ...s, ...meta, detail };
  }

  private sqlIndex(stepIdx: number): number {
    return this.response!.steps.slice(0, stepIdx + 1).filter(s => s.step_type === 'sql').length - 1;
  }

  trackByIdx(idx: number): number { return idx; }
}
