import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { AskRequest, AskResponse } from '../models/api.models';
import { environment } from '../../environments/environment';

@Injectable({ providedIn: 'root' })
export class AnalyticsService {
  private readonly base = environment.apiUrl;

  constructor(private http: HttpClient) {}

  ask(question: string, sessionId?: string): Observable<AskResponse> {
    const body: AskRequest = { question, session_id: sessionId };
    return this.http
      .post<AskResponse>(`${this.base}/api/v1/ask`, body)
      .pipe(catchError(this.handleError));
  }

  health(): Observable<{ status: string }> {
    return this.http.get<{ status: string }>(`${this.base}/api/v1/health`);
  }

  private handleError(err: HttpErrorResponse): Observable<never> {
    const msg =
      err.error?.detail ?? err.message ?? 'Unknown error from analytics API';
    return throwError(() => new Error(msg));
  }
}
