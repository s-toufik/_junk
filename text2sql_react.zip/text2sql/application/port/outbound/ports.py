"""
Outbound ports — abstract interfaces that the application layer
drives toward the outside world (DB, LLM, …).
"""

from __future__ import annotations

from abc import ABC, abstractmethod

from domain.model.models import DatabaseSchema, QueryPlanStep, QueryResult, SqlQuery


class SchemaRepository(ABC):
    """Reads the live database schema."""

    @abstractmethod
    def load_schema(self) -> DatabaseSchema: ...


class QueryExecutor(ABC):
    """Executes a validated SQL query and returns structured results."""

    @abstractmethod
    def execute(self, query: SqlQuery) -> QueryResult: ...


class LlmPort(ABC):
    """
    Talks to a language model using a ReAct loop.

    The LLM receives the question + all results collected so far,
    then decides its next step:
      - QUERY  → run this SQL and call me again with the result
      - ANSWER → I have enough data, here is my final answer

    This lets the LLM handle semantic questions by first fetching
    raw data (e.g. all distinct roles) and then reasoning over it,
    rather than trying to encode semantic logic in SQL.
    """

    @abstractmethod
    def plan_next_step(
        self,
        question: str,
        schema: DatabaseSchema,
        collected_results: list,   # list[CollectedResult] — avoid circular import
        history: list[dict[str, str]],
    ) -> "QueryPlanStep":
        """
        Return the next QueryPlanStep (QUERY or ANSWER).
        The LLM sees the question, the schema, and every result collected so far.
        """
        ...

    @abstractmethod
    def fix_sql(
        self,
        original_sql: str,
        error_message: str,
        schema: DatabaseSchema,
        history: list[dict[str, str]],
    ) -> str:
        """Ask the model to correct a failing SQL statement."""
        ...
