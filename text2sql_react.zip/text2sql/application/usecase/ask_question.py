"""
AskQuestionUseCase — ReAct loop
================================
The agent iterates between QUERY steps and a final ANSWER step.

Loop
----
1. Load schema
2. Ask LLM for next step (QUERY or ANSWER), passing the question,
   schema, and ALL results collected so far.
3. If QUERY:
   a. Validate SQL
   b. Inject LIMIT
   c. Execute
   d. Accumulate result into session.collected_results
   e. Go to 2
4. If ANSWER:
   - session.final_answer = step.answer
   - Done

This lets the LLM handle semantic questions by fetching raw data first
(e.g. SELECT DISTINCT role FROM employees) and then reasoning over the
actual values rather than guessing them in a WHERE clause.
"""

from __future__ import annotations

import logging

from application.port.inbound.text_to_sql_port import TextToSqlUseCase
from application.port.outbound.ports import LlmPort, QueryExecutor, SchemaRepository
from domain.model.models import (
    AgentSession,
    AgentTurn,
    CollectedResult,
    QueryStatus,
    StepType,
)
from domain.service.sql_services import (
    LimitInjectionService,
    SqlValidationError,
    SqlValidationService,
)

log = logging.getLogger(__name__)


class AskQuestionUseCase(TextToSqlUseCase):
    def __init__(
        self,
        schema_repo: SchemaRepository,
        query_executor: QueryExecutor,
        llm: LlmPort,
        validation_service: SqlValidationService | None = None,
        limit_service: LimitInjectionService | None = None,
        max_iterations: int = 10,
    ) -> None:
        self._schema_repo = schema_repo
        self._executor = query_executor
        self._llm = llm
        self._validator = validation_service or SqlValidationService()
        self._limiter = limit_service or LimitInjectionService()
        self._max_iter = max_iterations

    def ask(self, question: str) -> AgentSession:
        session = AgentSession(question=question)
        session.history.append(AgentTurn(role="user", content=question))

        schema = self._schema_repo.load_schema()
        log.debug("Schema loaded: %s", schema.table_names())

        lm_history: list[dict[str, str]] = []

        while session.iterations < self._max_iter:
            session.iterations += 1
            log.debug("Iteration %d/%d", session.iterations, self._max_iter)

            # ── Ask LLM for next step ─────────────────────────────────
            step = self._llm.plan_next_step(
                question=question,
                schema=schema,
                collected_results=session.collected_results,
                history=lm_history,
            )
            log.debug("Step: %s | Reasoning: %s", step.step_type, step.reasoning)

            # ── ANSWER branch ─────────────────────────────────────────
            if step.step_type == StepType.ANSWER:
                session.final_answer = step.answer
                session.status = QueryStatus.SUCCESS
                session.history.append(
                    AgentTurn(role="assistant", content=step.answer)
                )
                log.debug("Final answer after %d iteration(s).", session.iterations)
                return session

            # ── QUERY branch ──────────────────────────────────────────
            raw_sql = step.sql or ""
            session.history.append(
                AgentTurn(
                    role="assistant",
                    content=f"[REASONING] {step.reasoning}\n[SQL] {raw_sql}",
                )
            )
            lm_history.append({"role": "assistant", "content": f"[SQL] {raw_sql}"})

            # Validate
            try:
                validated = self._validator.validate(raw_sql)
            except SqlValidationError as exc:
                msg = f"[VALIDATION ERROR] {exc}"
                log.warning(msg)
                session.history.append(AgentTurn(role="tool_result", content=msg))
                lm_history.append({"role": "user", "content": msg})
                session.status = QueryStatus.VALIDATION_ERROR

                # Ask LLM to fix inline (doesn't consume an extra iteration)
                fixed_sql = self._llm.fix_sql(
                    original_sql=raw_sql,
                    error_message=str(exc),
                    schema=schema,
                    history=lm_history,
                )
                try:
                    validated = self._validator.validate(fixed_sql)
                    raw_sql = fixed_sql
                except SqlValidationError:
                    continue   # give up this iteration, LLM will re-plan

            # Inject LIMIT
            limited, was_limited = self._limiter.apply(validated)
            if was_limited:
                log.debug("Auto-LIMIT applied.")

            # Execute
            try:
                result = self._executor.execute(limited)
                result.truncated = was_limited
            except Exception as exc:  # noqa: BLE001
                msg = f"[DB ERROR] {exc}"
                log.warning(msg)
                session.history.append(AgentTurn(role="tool_result", content=msg))
                lm_history.append({"role": "user", "content": msg})
                session.status = QueryStatus.EXECUTION_ERROR

                fixed_sql = self._llm.fix_sql(
                    original_sql=raw_sql,
                    error_message=str(exc),
                    schema=schema,
                    history=lm_history,
                )
                lm_history.append({"role": "assistant", "content": f"[SQL] {fixed_sql}"})
                continue

            # Accumulate result
            collected = CollectedResult(
                sql=limited.normalised,
                result=result,
                reasoning=step.reasoning,
            )
            session.collected_results.append(collected)
            session.status = QueryStatus.SUCCESS

            # Feed result summary back to LLM history
            result_summary = (
                f"[RESULT for: {limited.normalised[:80]}]\n"
                f"{result.as_text_table()}"
            )
            session.history.append(
                AgentTurn(role="tool_result", content=result_summary)
            )
            lm_history.append({"role": "user", "content": result_summary})

        # Iteration limit reached
        session.status = QueryStatus.ITERATION_LIMIT
        session.final_answer = (
            f"Could not answer the question after {self._max_iter} attempts. "
            "Try rephrasing or simplifying the question."
        )
        return session
