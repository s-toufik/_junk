"""
Unit tests — ReAct-aware.
All LLM interactions are mocked; zero network/disk I/O.
"""

from __future__ import annotations

import pytest
from unittest.mock import MagicMock

from domain.model.models import (
    ColumnInfo,
    CollectedResult,
    DatabaseSchema,
    QueryPlanStep,
    QueryResult,
    QueryStatus,
    SqlQuery,
    StepType,
    TableSchema,
)
from domain.service.sql_services import (
    LimitInjectionService,
    SqlValidationError,
    SqlValidationService,
)
from application.usecase.ask_question import AskQuestionUseCase


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_schema() -> DatabaseSchema:
    col  = ColumnInfo(name="id",   type="INTEGER", primary_key=True)
    col2 = ColumnInfo(name="name", type="TEXT")
    col3 = ColumnInfo(name="role", type="TEXT")
    table = TableSchema(name="employees", columns=(col, col2, col3))
    return DatabaseSchema(tables=(table,))


def _result(rows=None, columns=None) -> QueryResult:
    columns = columns or ["id", "name"]
    rows = rows or [(1, "Alice")]
    return QueryResult(columns=columns, rows=rows, row_count=len(rows))


def _step_query(sql: str, reasoning: str = "fetch data") -> QueryPlanStep:
    return QueryPlanStep(step_type=StepType.QUERY, reasoning=reasoning, sql=sql)


def _step_answer(text: str = "Here is your answer.") -> QueryPlanStep:
    return QueryPlanStep(step_type=StepType.ANSWER, reasoning="done", answer=text)


def _build_use_case(
    steps: list[QueryPlanStep],
    execute_result: QueryResult | None = None,
    execute_side_effect=None,
    fix_sql_return: str = "SELECT id FROM employees",
    max_iterations: int = 10,
) -> AskQuestionUseCase:
    schema_repo = MagicMock()
    schema_repo.load_schema.return_value = _make_schema()

    executor = MagicMock()
    if execute_side_effect:
        executor.execute.side_effect = execute_side_effect
    else:
        executor.execute.return_value = execute_result or _result()

    llm = MagicMock()
    llm.plan_next_step.side_effect = steps
    llm.fix_sql.return_value = fix_sql_return

    return AskQuestionUseCase(
        schema_repo=schema_repo,
        query_executor=executor,
        llm=llm,
        max_iterations=max_iterations,
    )


# ---------------------------------------------------------------------------
# SqlValidationService
# ---------------------------------------------------------------------------

class TestSqlValidationService:
    svc = SqlValidationService()

    def test_valid_select(self):
        q = self.svc.validate("SELECT * FROM employees")
        assert isinstance(q, SqlQuery)

    def test_valid_explain(self):
        q = self.svc.validate("EXPLAIN SELECT id FROM employees")
        assert q.raw.startswith("EXPLAIN")

    def test_rejects_insert(self):
        with pytest.raises(SqlValidationError, match="INSERT"):
            self.svc.validate("INSERT INTO employees VALUES (1,'x','y')")

    def test_rejects_drop(self):
        with pytest.raises(SqlValidationError, match="DROP"):
            self.svc.validate("SELECT 1; DROP TABLE employees")

    def test_rejects_empty(self):
        with pytest.raises(SqlValidationError):
            self.svc.validate("   ")

    def test_rejects_update_disguised(self):
        with pytest.raises(SqlValidationError):
            self.svc.validate("-- comment\nUPDATE employees SET salary=0")

    def test_rejects_non_select(self):
        with pytest.raises(SqlValidationError):
            self.svc.validate("PRAGMA table_info('employees')")

    def test_comment_stripping_select(self):
        q = self.svc.validate("-- get all\nSELECT id FROM employees")
        assert isinstance(q, SqlQuery)


# ---------------------------------------------------------------------------
# LimitInjectionService
# ---------------------------------------------------------------------------

class TestLimitInjectionService:
    svc = LimitInjectionService(default_limit=50)

    def test_adds_limit(self):
        q = SqlQuery(raw="SELECT * FROM employees")
        limited, added = self.svc.apply(q)
        assert added is True
        assert "LIMIT 50" in limited.normalised

    def test_respects_existing_limit(self):
        q = SqlQuery(raw="SELECT * FROM employees LIMIT 10")
        limited, added = self.svc.apply(q)
        assert added is False

    def test_explain_not_limited(self):
        q = SqlQuery(raw="EXPLAIN SELECT * FROM employees")
        _, added = self.svc.apply(q)
        assert added is False

    def test_case_insensitive_limit_detection(self):
        q = SqlQuery(raw="SELECT * FROM employees limit 5")
        _, added = self.svc.apply(q)
        assert added is False


# ---------------------------------------------------------------------------
# DatabaseSchema helpers
# ---------------------------------------------------------------------------

class TestDatabaseSchema:
    def test_table_names(self):
        assert _make_schema().table_names() == ["employees"]

    def test_ddl_summary(self):
        summary = _make_schema().as_ddl_summary()
        assert "employees" in summary
        assert "id" in summary
        assert "PK" in summary


# ---------------------------------------------------------------------------
# QueryResult
# ---------------------------------------------------------------------------

class TestQueryResult:
    def test_empty(self):
        r = QueryResult(columns=["id"], rows=[], row_count=0)
        assert r.as_text_table() == "(no rows)"

    def test_renders_table(self):
        r = _result(rows=[(1, "Alice"), (2, "Bob")], columns=["id", "name"])
        txt = r.as_text_table()
        assert "Alice" in txt and "name" in txt


# ---------------------------------------------------------------------------
# AskQuestionUseCase — ReAct loop
# ---------------------------------------------------------------------------

class TestAskQuestionUseCase:

    def test_single_query_then_answer(self):
        """Happy path: one QUERY step then ANSWER."""
        uc = _build_use_case(steps=[
            _step_query("SELECT * FROM employees"),
            _step_answer("There is 1 employee."),
        ])
        session = uc.ask("How many employees?")
        assert session.status == QueryStatus.SUCCESS
        assert session.final_answer == "There is 1 employee."
        assert session.iterations == 2
        assert len(session.collected_results) == 1

    def test_semantic_two_step(self):
        """
        Simulates the semantic classification scenario:
        Step 1: fetch all distinct roles
        Step 2: answer after reasoning over them
        """
        roles_result = _result(
            rows=[("Lead Engineer",), ("HR Coordinator",), ("Backend Dev",)],
            columns=["role"],
        )
        uc = _build_use_case(
            steps=[
                _step_query(
                    "SELECT DISTINCT role FROM assignments",
                    reasoning="I need all roles to classify them semantically",
                ),
                _step_answer(
                    "The tech-related roles are Lead Engineer and Backend Dev. "
                    "Alice and Bob hold these roles."
                ),
            ],
            execute_result=roles_result,
        )
        session = uc.ask("Which employees have a tech-related role?")
        assert session.status == QueryStatus.SUCCESS
        assert len(session.collected_results) == 1
        assert session.collected_results[0].sql.startswith("SELECT DISTINCT role FROM assignments")
        assert "tech-related" in session.final_answer

    def test_multi_query_steps(self):
        """LLM may run several QUERY steps before answering."""
        uc = _build_use_case(steps=[
            _step_query("SELECT DISTINCT role FROM assignments"),
            _step_query("SELECT name, role FROM employees JOIN assignments ON id=employee_id"),
            _step_answer("Final answer after two queries."),
        ])
        session = uc.ask("Complex question")
        assert session.iterations == 3
        assert len(session.collected_results) == 2
        assert session.status == QueryStatus.SUCCESS

    def test_validation_error_triggers_fix(self):
        """A dangerous SQL triggers fix_sql; the fixed query succeeds."""
        uc = _build_use_case(
            steps=[
                _step_query("DROP TABLE employees"),   # will be rejected
                _step_answer("Done."),
            ],
            fix_sql_return="SELECT COUNT(*) FROM employees",
        )
        session = uc.ask("something bad")
        # The use case recovers via fix_sql inline, then continues
        assert session.status == QueryStatus.SUCCESS

    def test_db_error_triggers_fix_and_retry(self):
        """DB error on first execute triggers fix_sql and re-plan."""
        call_count = {"n": 0}

        def flaky(q):
            call_count["n"] += 1
            if call_count["n"] == 1:
                raise Exception("no such column: xyz")
            return _result()

        uc = _build_use_case(
            steps=[
                _step_query("SELECT xyz FROM employees"),
                _step_answer("Fixed answer."),
            ],
            execute_side_effect=flaky,
            fix_sql_return="SELECT id FROM employees",
        )
        session = uc.ask("bad column question")
        assert session.status == QueryStatus.SUCCESS

    def test_iteration_limit(self):
        """Infinite QUERY steps hit the cap and return ITERATION_LIMIT."""
        uc = _build_use_case(
            steps=[_step_query("SELECT * FROM employees")] * 20,
            max_iterations=3,
        )
        session = uc.ask("looping question")
        assert session.status == QueryStatus.ITERATION_LIMIT
        assert session.iterations == 3

    def test_direct_answer_no_query(self):
        """LLM may answer immediately without running any SQL."""
        uc = _build_use_case(steps=[
            _step_answer("I don't need SQL for that."),
        ])
        session = uc.ask("What is 2+2?")
        assert session.status == QueryStatus.SUCCESS
        assert session.iterations == 1
        assert len(session.collected_results) == 0

    def test_collected_results_accumulate(self):
        """Each QUERY step adds one CollectedResult."""
        uc = _build_use_case(steps=[
            _step_query("SELECT id FROM employees",   reasoning="first"),
            _step_query("SELECT name FROM employees", reasoning="second"),
            _step_answer("Done."),
        ])
        session = uc.ask("multi-step")
        assert len(session.collected_results) == 2
        assert session.collected_results[0].reasoning == "first"
        assert session.collected_results[1].reasoning == "second"
