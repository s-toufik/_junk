"""
CLI inbound adapter — interactive REPL and single-shot modes.
Drives TextToSqlUseCase from the command line.
"""

from __future__ import annotations

import sys

from application.port.inbound.text_to_sql_port import TextToSqlUseCase
from domain.model.models import AgentSession, CollectedResult, QueryStatus


_BANNER = """
╔══════════════════════════════════════════════╗
║         Text-to-SQL Agent  (SQLite)          ║
║  Type your question in natural language.     ║
║  Commands: :schema  :quit  :help             ║
╚══════════════════════════════════════════════╝
"""


def _render_session(session: AgentSession) -> None:
    print(f"\n[{session.iterations} iteration(s) | {len(session.collected_results)} query step(s)]")

    if session.status == QueryStatus.ITERATION_LIMIT:
        print("⚠  Iteration limit reached.")

    # Show each reasoning + SQL + result step
    for i, cr in enumerate(session.collected_results, 1):
        print(f"\n  ── Step {i} ──")
        print(f"  💭 {cr.reasoning}")
        print(f"  ▶  SQL: {cr.sql}")
        rows_preview = cr.result.as_text_table().split("\n")
        preview = "\n     ".join(rows_preview[:8])
        print(f"     {preview}")
        if len(rows_preview) > 8:
            print(f"     … ({cr.result.row_count} rows total)")

    # Show validation / db errors from history
    for turn in session.history:
        if turn.role == "tool_result" and (
            "[VALIDATION ERROR]" in turn.content or "[DB ERROR]" in turn.content
        ):
            print(f"\n  ✗ {turn.content}")

    print(f"\n✅ Answer:\n{session.final_answer}\n")


class CliAdapter:
    def __init__(self, use_case: TextToSqlUseCase, schema_summary_fn=None) -> None:
        self._use_case = use_case
        self._schema_fn = schema_summary_fn  # callable() → str, optional

    def run_repl(self) -> None:
        print(_BANNER)
        while True:
            try:
                line = input("❯ ").strip()
            except (EOFError, KeyboardInterrupt):
                print("\nBye!")
                break

            if not line:
                continue
            if line.lower() in (":quit", ":exit", ":q"):
                print("Bye!")
                break
            if line.lower() == ":help":
                print("  :schema  — show database schema")
                print("  :quit    — exit")
                continue
            if line.lower() == ":schema":
                if self._schema_fn:
                    print(self._schema_fn())
                else:
                    print("(schema introspection not wired)")
                continue

            session = self._use_case.ask(line)
            _render_session(session)

    def run_once(self, question: str) -> int:
        """Non-interactive mode; returns exit code."""
        session = self._use_case.ask(question)
        _render_session(session)
        return 0 if session.status == QueryStatus.SUCCESS else 1
