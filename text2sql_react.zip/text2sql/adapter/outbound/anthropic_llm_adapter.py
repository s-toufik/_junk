"""
Anthropic (Claude) outbound adapter implementing LlmPort (ReAct protocol).

The LLM receives a structured prompt and must reply with a JSON object:

  { "step_type": "QUERY", "reasoning": "...", "sql": "SELECT ..." }
  { "step_type": "ANSWER", "reasoning": "...", "answer": "..." }

This forces the model to be explicit about *why* it is running each query,
which solves the semantic classification problem:

  Q: "Which employees have a tech-related role?"
  → Step 1 QUERY: "I need to see all distinct roles first"
              SQL: SELECT DISTINCT role FROM assignments
  → Step 2 ANSWER: "Based on the roles I retrieved, the tech-related ones
                    are Lead Engineer, Backend Dev, Architect, DevOps, Full-Stack Dev.
                    The employees holding these roles are: ..."
"""

from __future__ import annotations

import json
import logging
import re

import anthropic

from application.port.outbound.ports import LlmPort
from domain.model.models import (
    CollectedResult,
    DatabaseSchema,
    QueryPlanStep,
    QueryResult,
    StepType,
)

log = logging.getLogger(__name__)

_SQL_FENCE = re.compile(r"```(?:sql)?\s*(.*?)```", re.DOTALL | re.IGNORECASE)
_JSON_FENCE = re.compile(r"```(?:json)?\s*(.*?)```", re.DOTALL | re.IGNORECASE)

_SYSTEM_PROMPT = """\
You are a SQLite expert assistant that answers questions about a database
using a structured ReAct (Reason + Act) loop.

Each turn you must output a single JSON object — nothing else, no prose outside it.

Two possible responses:

1. Run a SQL query to gather data:
{
  "step_type": "QUERY",
  "reasoning": "<why you need this data>",
  "sql": "<read-only SELECT statement>"
}

2. Produce the final answer (when you have enough data):
{
  "step_type": "ANSWER",
  "reasoning": "<how you drew this conclusion>",
  "answer": "<clear natural-language answer to the user's question>"
}

SQL rules:
- Only SELECT or EXPLAIN SELECT statements.
- Never INSERT, UPDATE, DELETE, DROP, CREATE, ALTER, TRUNCATE, ATTACH, PRAGMA.
- Do NOT add a LIMIT clause — the system handles that automatically.
- Use only table and column names present in the schema.

Strategy rules:
- For SEMANTIC questions (e.g. "tech-related", "senior", "relevant"),
  NEVER guess values in a WHERE clause.
  Instead, first run a QUERY to fetch the raw data (e.g. all distinct roles),
  then decide in your ANSWER step which items match the semantic criterion.
- For EXACT questions (e.g. "salary > 90000"), a single QUERY is usually enough.
- You may run multiple QUERY steps before answering.
- Once you have the data you need, output ANSWER immediately.
"""


def _extract_json(text: str) -> dict:
    """
    Extract the JSON payload from the LLM response.
    Handles raw JSON, ```json fences, and stray prose around it.
    """
    # Try fenced JSON first
    m = _JSON_FENCE.search(text)
    if m:
        return json.loads(m.group(1).strip())

    # Try bare JSON object
    start = text.find("{")
    end = text.rfind("}") + 1
    if start != -1 and end > start:
        return json.loads(text[start:end])

    raise ValueError(f"No JSON object found in LLM response: {text[:200]!r}")


def _format_collected(collected_results: list[CollectedResult]) -> str:
    if not collected_results:
        return "(no queries run yet)"
    parts = []
    for i, cr in enumerate(collected_results, 1):
        parts.append(
            f"--- Result {i} (reasoning: {cr.reasoning}) ---\n"
            f"SQL: {cr.sql}\n"
            f"{cr.result.as_text_table()}"
        )
    return "\n\n".join(parts)


class AnthropicLlmAdapter(LlmPort):
    def __init__(
        self,
        api_key: str,
        model: str = "claude-sonnet-4-6",
        max_tokens: int = 1024,
    ) -> None:
        self._client = anthropic.Anthropic(api_key=api_key)
        self._model = model
        self._max_tokens = max_tokens

    def _complete(self, messages: list[dict]) -> str:
        response = self._client.messages.create(
            model=self._model,
            max_tokens=self._max_tokens,
            system=_SYSTEM_PROMPT,
            messages=messages,
        )
        return response.content[0].text.strip()

    # ------------------------------------------------------------------
    # LlmPort
    # ------------------------------------------------------------------

    def plan_next_step(
        self,
        question: str,
        schema: DatabaseSchema,
        collected_results: list[CollectedResult],
        history: list[dict[str, str]],
    ) -> QueryPlanStep:
        collected_text = _format_collected(collected_results)
        prompt = (
            f"Database schema:\n{schema.as_ddl_summary()}\n\n"
            f"User question: {question}\n\n"
            f"Data collected so far:\n{collected_text}\n\n"
            "Decide your next step. Output ONLY the JSON object."
        )
        messages = [*history, {"role": "user", "content": prompt}]
        raw = self._complete(messages)
        log.debug("LLM raw step: %s", raw[:300])

        try:
            data = _extract_json(raw)
        except (ValueError, json.JSONDecodeError) as exc:
            log.warning("Failed to parse LLM JSON (%s) — defaulting to ANSWER", exc)
            return QueryPlanStep(
                step_type=StepType.ANSWER,
                reasoning="JSON parse error",
                answer=raw,  # surface raw text as answer
            )

        step_type = StepType(data.get("step_type", "ANSWER"))
        reasoning = data.get("reasoning", "")

        if step_type == StepType.QUERY:
            sql = data.get("sql", "")
            # Strip fences in case model nested them
            m = _SQL_FENCE.search(sql)
            if m:
                sql = m.group(1).strip()
            return QueryPlanStep(step_type=StepType.QUERY, reasoning=reasoning, sql=sql)

        return QueryPlanStep(
            step_type=StepType.ANSWER,
            reasoning=reasoning,
            answer=data.get("answer", ""),
        )

    def fix_sql(
        self,
        original_sql: str,
        error_message: str,
        schema: DatabaseSchema,
        history: list[dict[str, str]],
    ) -> str:
        prompt = (
            f"Database schema:\n{schema.as_ddl_summary()}\n\n"
            f"The following SQL query failed:\n{original_sql}\n\n"
            f"Error: {error_message}\n\n"
            'Fix the query. Output ONLY JSON: {"step_type":"QUERY","reasoning":"...","sql":"..."}'
        )
        messages = [*history, {"role": "user", "content": prompt}]
        raw = self._complete(messages)
        try:
            data = _extract_json(raw)
            sql = data.get("sql", raw)
        except (ValueError, json.JSONDecodeError):
            sql = raw
        m = _SQL_FENCE.search(sql)
        return m.group(1).strip() if m else sql.strip()
