"""
CLI inbound adapter — interactive REPL and single-shot modes.
Drives TextToSqlUseCase from the command line.
"""

from __future__ import annotations

import sys

from application.port.inbound.text_to_sql_port import TextToSqlUseCase
from domain.model.models import AgentSession, QueryStatus


_BANNER = """
╔══════════════════════════════════════════════╗
║         Text-to-SQL Agent  (SQLite)          ║
║  Type your question in natural language.     ║
║  Commands: :schema  :quit  :help             ║
╚══════════════════════════════════════════════╝
"""


def _render_session(session: AgentSession) -> None:
    print(f"\n[{session.iterations} iteration(s)]")
    if session.status == QueryStatus.ITERATION_LIMIT:
        print("⚠  Iteration limit reached.")
    elif session.status in (QueryStatus.VALIDATION_ERROR, QueryStatus.EXECUTION_ERROR):
        print("⚠  Query failed — see history below.")

    # Show intermediate steps (collapsed)
    for turn in session.history:
        if turn.role == "assistant" and turn.content.startswith("[SQL]"):
            print(f"\n  ▶ Generated SQL:\n    {turn.content[6:]}")
        elif turn.role == "tool_result":
            print(f"  ✗ {turn.content}")

    print(f"\n✅ Answer:\n{session.final_answer}\n")


class CliAdapter:
    def __init__(self, use_case: TextToSqlUseCase, schema_summary_fn=None) -> None:
        self._use_case = use_case
        self._schema_fn = schema_summary_fn  # callable() → str, optional

    def run_repl(self) -> None:
        print(_BANNER)
        while True:
            try:
                line = input("❯ ").strip()
            except (EOFError, KeyboardInterrupt):
                print("\nBye!")
                break

            if not line:
                continue
            if line.lower() in (":quit", ":exit", ":q"):
                print("Bye!")
                break
            if line.lower() == ":help":
                print("  :schema  — show database schema")
                print("  :quit    — exit")
                continue
            if line.lower() == ":schema":
                if self._schema_fn:
                    print(self._schema_fn())
                else:
                    print("(schema introspection not wired)")
                continue

            session = self._use_case.ask(line)
            _render_session(session)

    def run_once(self, question: str) -> int:
        """Non-interactive mode; returns exit code."""
        session = self._use_case.ask(question)
        _render_session(session)
        return 0 if session.status == QueryStatus.SUCCESS else 1
