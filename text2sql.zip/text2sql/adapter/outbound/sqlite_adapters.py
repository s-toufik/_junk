"""
SQLite outbound adapters: SchemaRepository + QueryExecutor.
"""

from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from typing import Generator

from application.port.outbound.ports import QueryExecutor, SchemaRepository
from domain.model.models import ColumnInfo, DatabaseSchema, QueryResult, SqlQuery, TableSchema


class SqliteConnectionFactory:
    """Thin wrapper so we never hard-code the path in multiple places."""

    def __init__(self, db_path: str) -> None:
        self._path = db_path

    @contextmanager
    def connect(self) -> Generator[sqlite3.Connection, None, None]:
        conn = sqlite3.connect(self._path)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
        finally:
            conn.close()


# ---------------------------------------------------------------------------
# Schema introspection
# ---------------------------------------------------------------------------


class SqliteSchemaRepository(SchemaRepository):
    """
    Loads the full schema by querying sqlite_master and PRAGMA table_info.
    No hardcoded table/column names — fully dynamic.
    """

    def __init__(self, factory: SqliteConnectionFactory) -> None:
        self._factory = factory

    def load_schema(self) -> DatabaseSchema:
        with self._factory.connect() as conn:
            # list all user tables (exclude SQLite internals)
            rows = conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
            ).fetchall()
            tables: list[TableSchema] = []
            for row in rows:
                table_name: str = row["name"]
                cols = conn.execute(f'PRAGMA table_info("{table_name}")').fetchall()
                columns = tuple(
                    ColumnInfo(
                        name=col["name"],
                        type=col["type"] or "TEXT",
                        nullable=col["notnull"] == 0,
                        primary_key=col["pk"] > 0,
                        default=col["dflt_value"],
                    )
                    for col in cols
                )
                tables.append(TableSchema(name=table_name, columns=columns))
        return DatabaseSchema(tables=tuple(tables))


# ---------------------------------------------------------------------------
# Query execution
# ---------------------------------------------------------------------------


class SqliteQueryExecutor(QueryExecutor):
    """Executes read-only SQL statements against a SQLite database."""

    def __init__(self, factory: SqliteConnectionFactory) -> None:
        self._factory = factory

    def execute(self, query: SqlQuery) -> QueryResult:
        with self._factory.connect() as conn:
            # Belt-and-suspenders: open in read-only URI mode
            cursor = conn.execute(query.normalised)
            description = cursor.description or []
            columns = [d[0] for d in description]
            rows = [tuple(r) for r in cursor.fetchall()]
        return QueryResult(
            columns=columns,
            rows=rows,
            row_count=len(rows),
        )
