"""
Anthropic (Claude) outbound adapter implementing LlmPort.
Uses the Anthropic Python SDK with a tool-use-style prompt pattern.
"""

from __future__ import annotations

import logging
import re

import anthropic

from application.port.outbound.ports import LlmPort
from domain.model.models import DatabaseSchema, QueryResult

log = logging.getLogger(__name__)

_SQL_FENCE = re.compile(r"```(?:sql)?\s*(.*?)```", re.DOTALL | re.IGNORECASE)

_SYSTEM_PROMPT = """\
You are a SQLite expert assistant. Your job is to translate natural-language
questions into correct, read-only SQLite SELECT statements.

Rules you MUST follow:
- Only produce SELECT or EXPLAIN SELECT statements.
- Never use INSERT, UPDATE, DELETE, DROP, CREATE, ALTER, TRUNCATE, ATTACH,
  PRAGMA (write forms), or any other write/DDL keywords.
- Do NOT add a LIMIT clause — the system will add one automatically.
- Return ONLY the SQL statement, with no explanation, no markdown, no preamble.
  If you must wrap it in a code fence, use ```sql … ```.
- Use only table and column names that appear in the schema provided.
"""


def _extract_sql(text: str) -> str:
    """Strip markdown fences if the model wraps the query."""
    m = _SQL_FENCE.search(text)
    return m.group(1).strip() if m else text.strip()


class AnthropicLlmAdapter(LlmPort):
    def __init__(
        self,
        api_key: str,
        model: str = "claude-sonnet-4-6",
        max_tokens: int = 512,
    ) -> None:
        self._client = anthropic.Anthropic(api_key=api_key)
        self._model = model
        self._max_tokens = max_tokens

    # ------------------------------------------------------------------
    # Internal helper
    # ------------------------------------------------------------------

    def _complete(self, messages: list[dict]) -> str:
        response = self._client.messages.create(
            model=self._model,
            max_tokens=self._max_tokens,
            system=_SYSTEM_PROMPT,
            messages=messages,
        )
        return response.content[0].text.strip()

    # ------------------------------------------------------------------
    # LlmPort
    # ------------------------------------------------------------------

    def generate_sql(
        self,
        question: str,
        schema: DatabaseSchema,
        history: list[dict[str, str]],
    ) -> str:
        prompt = (
            f"Database schema:\n{schema.as_ddl_summary()}\n\n"
            f"Question: {question}\n\n"
            "Return ONLY the SQL query."
        )
        messages = [*history, {"role": "user", "content": prompt}]
        raw = self._complete(messages)
        log.debug("LLM raw SQL: %s", raw[:200])
        return _extract_sql(raw)

    def generate_answer(
        self,
        question: str,
        sql: str,
        result: QueryResult,
    ) -> str:
        table = result.as_text_table()
        truncation_note = (
            f"\n(Results automatically limited to {result.row_count} rows.)"
            if result.truncated
            else ""
        )
        prompt = (
            f"The user asked: {question}\n\n"
            f"You executed this SQL:\n{sql}\n\n"
            f"Result ({result.row_count} rows):\n{table}{truncation_note}\n\n"
            "Write a concise, clear natural-language answer. "
            "Do not repeat the SQL or the raw table unless it adds clarity."
        )
        response = self._client.messages.create(
            model=self._model,
            max_tokens=512,
            messages=[{"role": "user", "content": prompt}],
        )
        return response.content[0].text.strip()

    def fix_sql(
        self,
        original_sql: str,
        error_message: str,
        schema: DatabaseSchema,
        history: list[dict[str, str]],
    ) -> str:
        prompt = (
            f"Database schema:\n{schema.as_ddl_summary()}\n\n"
            f"The following SQL query failed:\n{original_sql}\n\n"
            f"Error: {error_message}\n\n"
            "Fix the query so it runs correctly. Return ONLY the corrected SQL."
        )
        messages = [*history, {"role": "user", "content": prompt}]
        raw = self._complete(messages)
        log.debug("LLM fixed SQL: %s", raw[:200])
        return _extract_sql(raw)
