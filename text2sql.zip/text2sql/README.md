# Text-to-SQL Agent — Hexagonal Architecture

A production-ready **Text-to-SQL agent** that translates natural-language
questions into safe, read-only SQLite queries and returns natural-language
answers, powered by Claude (Anthropic).

## Features

| Feature | Where it lives |
|---|---|
| **Schema introspection** | `SqliteSchemaRepository` — queries `sqlite_master` + `PRAGMA table_info` at runtime |
| **Read-only enforcement** | `SqlValidationService` — blocks INSERT/UPDATE/DELETE/DROP/… |
| **Auto-LIMIT** | `LimitInjectionService` — appends `LIMIT N` when no limit is present |
| **SQL validation** | `SqlValidationService` — regex + leading-keyword check before any execution |
| **Error recovery** | `AskQuestionUseCase` — feeds DB errors back to LLM for auto-correction |
| **Iteration cap** | `AskQuestionUseCase(max_iterations=10)` — prevents infinite loops |

## Architecture

```
text2sql/
├── domain/
│   ├── model/          # Pure dataclasses (SqlQuery, QueryResult, DatabaseSchema, …)
│   └── service/        # SqlValidationService, LimitInjectionService
├── application/
│   ├── port/
│   │   ├── inbound/    # TextToSqlUseCase (ABC)
│   │   └── outbound/   # SchemaRepository, QueryExecutor, LlmPort (ABCs)
│   └── usecase/        # AskQuestionUseCase — agentic loop
├── adapter/
│   ├── inbound/        # CliAdapter (REPL + single-shot)
│   └── outbound/       # SqliteSchemaRepository, SqliteQueryExecutor, AnthropicLlmAdapter
├── infrastructure/     # seed_db.py — creates & seeds demo.db
├── bootstrap/          # Container — DI wiring via @cached_property
├── tests/              # 20 unit tests, zero I/O
└── main.py
```

## Quickstart

```bash
# 1. Install
pip install anthropic

# 2. Set env vars
export ANTHROPIC_API_KEY=sk-ant-...
export TEXT2SQL_DB_PATH=demo.db     # optional, default: demo.db
export TEXT2SQL_MAX_ITERATIONS=10   # optional
export TEXT2SQL_DEFAULT_LIMIT=100   # optional

# 3a. Interactive REPL (seeds demo.db on first run)
python main.py

# 3b. Single question
python main.py "Who are the top 3 highest-paid employees?"

# 4. Run tests
python -m pytest
```

## REPL commands

| Command | Action |
|---|---|
| `:schema` | Print the live database schema |
| `:quit` / `:q` | Exit |
| `:help` | Show help |

## Demo database

Three tables seeded automatically:

- **employees** (id, name, department, salary, hire_date)
- **projects** (id, name, budget, start_date, end_date)
- **assignments** (employee_id, project_id, role)

## Environment variables

| Variable | Default | Description |
|---|---|---|
| `ANTHROPIC_API_KEY` | *(required)* | Your Anthropic API key |
| `TEXT2SQL_DB_PATH` | `demo.db` | Path to the SQLite database |
| `TEXT2SQL_MODEL` | `claude-sonnet-4-6` | Anthropic model to use |
| `TEXT2SQL_MAX_ITERATIONS` | `10` | Max agentic loop iterations |
| `TEXT2SQL_DEFAULT_LIMIT` | `100` | Auto-LIMIT value |

## Extending

**New database** — Point `TEXT2SQL_DB_PATH` at any SQLite file. The schema is
introspected dynamically; no code changes needed.

**New LLM** — Implement `LlmPort` (3 methods) and swap the adapter in
`Container`.

**FastAPI endpoint** — Implement a new inbound adapter that calls
`TextToSqlUseCase.ask(question)` and serialises `AgentSession`.
