"""
Unit tests for domain services and core use case.
No I/O — all dependencies are mocked.
"""

from __future__ import annotations

import pytest

from domain.model.models import (
    ColumnInfo,
    DatabaseSchema,
    QueryResult,
    QueryStatus,
    SqlQuery,
    TableSchema,
)
from domain.service.sql_services import (
    LimitInjectionService,
    SqlValidationError,
    SqlValidationService,
)


# ---------------------------------------------------------------------------
# SqlValidationService
# ---------------------------------------------------------------------------

class TestSqlValidationService:
    svc = SqlValidationService()

    def test_valid_select(self):
        q = self.svc.validate("SELECT * FROM employees")
        assert isinstance(q, SqlQuery)

    def test_valid_explain(self):
        q = self.svc.validate("EXPLAIN SELECT id FROM projects")
        assert q.raw.startswith("EXPLAIN")

    def test_rejects_insert(self):
        with pytest.raises(SqlValidationError, match="INSERT"):
            self.svc.validate("INSERT INTO employees VALUES (1,'x','y',0,'2020-01-01')")

    def test_rejects_drop(self):
        with pytest.raises(SqlValidationError, match="DROP"):
            self.svc.validate("SELECT 1; DROP TABLE employees")

    def test_rejects_empty(self):
        with pytest.raises(SqlValidationError):
            self.svc.validate("   ")

    def test_rejects_update_disguised(self):
        with pytest.raises(SqlValidationError):
            self.svc.validate("-- comment\nUPDATE employees SET salary=0")

    def test_rejects_non_select(self):
        with pytest.raises(SqlValidationError):
            self.svc.validate("PRAGMA table_info('employees')")

    def test_comment_stripping_select(self):
        q = self.svc.validate("-- get all\nSELECT id FROM employees")
        assert isinstance(q, SqlQuery)


# ---------------------------------------------------------------------------
# LimitInjectionService
# ---------------------------------------------------------------------------

class TestLimitInjectionService:
    svc = LimitInjectionService(default_limit=50)

    def test_adds_limit(self):
        q = SqlQuery(raw="SELECT * FROM employees")
        limited, added = self.svc.apply(q)
        assert added is True
        assert "LIMIT 50" in limited.normalised

    def test_respects_existing_limit(self):
        q = SqlQuery(raw="SELECT * FROM employees LIMIT 10")
        limited, added = self.svc.apply(q)
        assert added is False
        assert limited.normalised == q.normalised

    def test_explain_not_limited(self):
        q = SqlQuery(raw="EXPLAIN SELECT * FROM employees")
        limited, added = self.svc.apply(q)
        assert added is False

    def test_case_insensitive_limit_detection(self):
        q = SqlQuery(raw="SELECT * FROM employees limit 5")
        _, added = self.svc.apply(q)
        assert added is False


# ---------------------------------------------------------------------------
# DatabaseSchema helpers
# ---------------------------------------------------------------------------

def _make_schema() -> DatabaseSchema:
    col = ColumnInfo(name="id", type="INTEGER", primary_key=True)
    col2 = ColumnInfo(name="name", type="TEXT")
    table = TableSchema(name="users", columns=(col, col2))
    return DatabaseSchema(tables=(table,))


class TestDatabaseSchema:
    def test_table_names(self):
        schema = _make_schema()
        assert schema.table_names() == ["users"]

    def test_ddl_summary_contains_column(self):
        schema = _make_schema()
        summary = schema.as_ddl_summary()
        assert "users" in summary
        assert "id" in summary
        assert "PK" in summary


# ---------------------------------------------------------------------------
# QueryResult.as_text_table
# ---------------------------------------------------------------------------

class TestQueryResult:
    def test_empty(self):
        r = QueryResult(columns=["id"], rows=[], row_count=0)
        assert r.as_text_table() == "(no rows)"

    def test_renders_table(self):
        r = QueryResult(
            columns=["id", "name"],
            rows=[(1, "Alice"), (2, "Bob")],
            row_count=2,
        )
        txt = r.as_text_table()
        assert "Alice" in txt
        assert "name" in txt


# ---------------------------------------------------------------------------
# AskQuestionUseCase (mocked dependencies)
# ---------------------------------------------------------------------------

from unittest.mock import MagicMock

from application.usecase.ask_question import AskQuestionUseCase


def _build_use_case(
    sql_to_return: str = "SELECT * FROM employees",
    answer: str = "There are 10 employees.",
    execute_side_effect=None,
    fix_sql_return: str | None = None,
    max_iterations: int = 10,
) -> AskQuestionUseCase:
    schema_repo = MagicMock()
    schema_repo.load_schema.return_value = _make_schema()

    executor = MagicMock()
    if execute_side_effect:
        executor.execute.side_effect = execute_side_effect
    else:
        executor.execute.return_value = QueryResult(
            columns=["id", "name"], rows=[(1, "Alice")], row_count=1
        )

    llm = MagicMock()
    llm.generate_sql.return_value = sql_to_return
    llm.generate_answer.return_value = answer
    llm.fix_sql.return_value = fix_sql_return or sql_to_return

    return AskQuestionUseCase(
        schema_repo=schema_repo,
        query_executor=executor,
        llm=llm,
        max_iterations=max_iterations,
    )


class TestAskQuestionUseCase:
    def test_happy_path(self):
        uc = _build_use_case()
        session = uc.ask("How many employees?")
        assert session.status == QueryStatus.SUCCESS
        assert session.final_answer == "There are 10 employees."
        assert session.iterations == 1

    def test_blocks_dangerous_sql_and_recovers(self):
        # First call returns DROP, second call returns valid SELECT
        uc = _build_use_case(
            sql_to_return="DROP TABLE employees",
            fix_sql_return="SELECT COUNT(*) FROM employees",
        )
        session = uc.ask("delete everything")
        # Should recover on second iteration
        assert session.status == QueryStatus.SUCCESS
        assert session.iterations == 2

    def test_execution_error_recovery(self):
        call_count = {"n": 0}

        def flaky_execute(q):
            call_count["n"] += 1
            if call_count["n"] == 1:
                raise Exception("no such column: xyz")
            return QueryResult(columns=["id"], rows=[(1,)], row_count=1)

        uc = _build_use_case(execute_side_effect=flaky_execute)
        session = uc.ask("show xyz column")
        assert session.status == QueryStatus.SUCCESS
        assert session.iterations == 2

    def test_iteration_limit(self):
        uc = _build_use_case(
            sql_to_return="DROP TABLE employees",  # always invalid
            max_iterations=3,
        )
        session = uc.ask("cause infinite loop")
        assert session.status == QueryStatus.ITERATION_LIMIT
        assert session.iterations == 3
