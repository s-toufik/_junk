"""
Inbound port — what callers (CLI, API, …) can ask the application to do.
"""

from __future__ import annotations

from abc import ABC, abstractmethod

from domain.model.models import AgentSession


class TextToSqlUseCase(ABC):
    """Primary port: translate a natural-language question into SQL and run it."""

    @abstractmethod
    def ask(self, question: str) -> AgentSession: ...
