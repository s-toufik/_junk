"""
Outbound ports — abstract interfaces that the application layer
drives toward the outside world (DB, LLM, …).
"""

from __future__ import annotations

from abc import ABC, abstractmethod

from domain.model.models import DatabaseSchema, QueryResult, SqlQuery


class SchemaRepository(ABC):
    """Reads the live database schema."""

    @abstractmethod
    def load_schema(self) -> DatabaseSchema: ...


class QueryExecutor(ABC):
    """Executes a validated SQL query and returns structured results."""

    @abstractmethod
    def execute(self, query: SqlQuery) -> QueryResult: ...


class LlmPort(ABC):
    """Talks to a language model to translate NL → SQL and produce answers."""

    @abstractmethod
    def generate_sql(
        self,
        question: str,
        schema: DatabaseSchema,
        history: list[dict[str, str]],
    ) -> str:
        """Return raw SQL string (may be invalid — caller validates)."""
        ...

    @abstractmethod
    def generate_answer(
        self,
        question: str,
        sql: str,
        result: QueryResult,
    ) -> str:
        """Produce a natural-language answer given the query result."""
        ...

    @abstractmethod
    def fix_sql(
        self,
        original_sql: str,
        error_message: str,
        schema: DatabaseSchema,
        history: list[dict[str, str]],
    ) -> str:
        """Ask the model to correct a failing SQL statement."""
        ...
