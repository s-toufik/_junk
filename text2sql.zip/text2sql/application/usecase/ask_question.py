"""
AskQuestionUseCase
==================
Orchestrates the full agentic Text-to-SQL loop:

  1. Load schema via SchemaRepository
  2. Ask LLM to produce SQL
  3. Validate SQL (SqlValidationService)
  4. Inject LIMIT (LimitInjectionService)
  5. Execute via QueryExecutor
  6. On error → feed DB error back to LLM (error recovery, up to max_iterations)
  7. Ask LLM to produce a natural-language answer
"""

from __future__ import annotations

import logging

from application.port.inbound.text_to_sql_port import TextToSqlUseCase
from application.port.outbound.ports import LlmPort, QueryExecutor, SchemaRepository
from domain.model.models import AgentSession, AgentTurn, QueryStatus
from domain.service.sql_services import LimitInjectionService, SqlValidationError, SqlValidationService

log = logging.getLogger(__name__)


class AskQuestionUseCase(TextToSqlUseCase):
    def __init__(
        self,
        schema_repo: SchemaRepository,
        query_executor: QueryExecutor,
        llm: LlmPort,
        validation_service: SqlValidationService | None = None,
        limit_service: LimitInjectionService | None = None,
        max_iterations: int = 10,
    ) -> None:
        self._schema_repo = schema_repo
        self._executor = query_executor
        self._llm = llm
        self._validator = validation_service or SqlValidationService()
        self._limiter = limit_service or LimitInjectionService()
        self._max_iter = max_iterations

    # ------------------------------------------------------------------
    def ask(self, question: str) -> AgentSession:
        session = AgentSession(question=question)
        session.history.append(AgentTurn(role="user", content=question))

        schema = self._schema_repo.load_schema()
        log.debug("Schema loaded: %s", schema.table_names())

        lm_history: list[dict[str, str]] = []

        while session.iterations < self._max_iter:
            session.iterations += 1
            log.debug("Iteration %d/%d", session.iterations, self._max_iter)

            # ---- Generate SQL -----------------------------------------
            if session.iterations == 1:
                raw_sql = self._llm.generate_sql(question, schema, lm_history)
            else:
                # Error-recovery branch: last history entry has the error
                last_error = session.history[-1].content
                raw_sql = self._llm.fix_sql(
                    original_sql=_last_sql(session),
                    error_message=last_error,
                    schema=schema,
                    history=lm_history,
                )

            session.history.append(AgentTurn(role="assistant", content=f"[SQL] {raw_sql}"))
            lm_history.append({"role": "assistant", "content": raw_sql})

            # ---- Validate ---------------------------------------------
            try:
                validated = self._validator.validate(raw_sql)
            except SqlValidationError as exc:
                msg = f"[VALIDATION ERROR] {exc}"
                log.warning(msg)
                session.history.append(AgentTurn(role="tool_result", content=msg))
                lm_history.append({"role": "user", "content": msg})
                session.status = QueryStatus.VALIDATION_ERROR
                continue  # ask LLM to fix

            # ---- Inject LIMIT ----------------------------------------
            limited, was_limited = self._limiter.apply(validated)
            if was_limited:
                log.debug("Auto-LIMIT applied: %s", limited.normalised[-60:])

            # ---- Execute ----------------------------------------------
            try:
                result = self._executor.execute(limited)
                result.truncated = was_limited
            except Exception as exc:  # noqa: BLE001
                msg = f"[DB ERROR] {exc}"
                log.warning(msg)
                session.history.append(AgentTurn(role="tool_result", content=msg))
                lm_history.append({"role": "user", "content": msg})
                session.status = QueryStatus.EXECUTION_ERROR
                continue  # ask LLM to fix

            # ---- Produce natural-language answer ----------------------
            session.final_answer = self._llm.generate_answer(
                question=question,
                sql=limited.normalised,
                result=result,
            )
            session.status = QueryStatus.SUCCESS
            session.history.append(
                AgentTurn(role="assistant", content=session.final_answer)
            )
            log.debug("Answer generated after %d iteration(s).", session.iterations)
            return session

        # Exhausted iterations
        session.status = QueryStatus.ITERATION_LIMIT
        session.final_answer = (
            f"Could not answer the question after {self._max_iter} attempts. "
            "Try rephrasing or simplifying the question."
        )
        return session


def _last_sql(session: AgentSession) -> str:
    """Extract the most recent SQL from session history."""
    for turn in reversed(session.history):
        if turn.role == "assistant" and turn.content.startswith("[SQL]"):
            return turn.content[len("[SQL] "):]
    return ""
