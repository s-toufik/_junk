"""
Domain models for the Text-to-SQL agent.
Pure dataclasses — no framework dependencies.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any


# ---------------------------------------------------------------------------
# Schema introspection models
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ColumnInfo:
    name: str
    type: str
    nullable: bool = True
    primary_key: bool = False
    default: str | None = None


@dataclass(frozen=True)
class TableSchema:
    name: str
    columns: tuple[ColumnInfo, ...]

    def column_names(self) -> list[str]:
        return [c.name for c in self.columns]


@dataclass(frozen=True)
class DatabaseSchema:
    tables: tuple[TableSchema, ...]

    def table_names(self) -> list[str]:
        return [t.name for t in self.tables]

    def as_ddl_summary(self) -> str:
        """Human-readable schema summary passed to the LLM."""
        lines: list[str] = []
        for table in self.tables:
            cols = ", ".join(
                f"{c.name} {c.type}{'  PK' if c.primary_key else ''}"
                for c in table.columns
            )
            lines.append(f"  TABLE {table.name} ({cols})")
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Query models
# ---------------------------------------------------------------------------


class QueryStatus(Enum):
    SUCCESS = auto()
    VALIDATION_ERROR = auto()
    EXECUTION_ERROR = auto()
    ITERATION_LIMIT = auto()


@dataclass
class SqlQuery:
    """A validated, read-only SQL query."""

    raw: str

    @property
    def normalised(self) -> str:
        return self.raw.strip().rstrip(";")


@dataclass
class QueryResult:
    columns: list[str]
    rows: list[tuple[Any, ...]]
    row_count: int
    truncated: bool = False  # True when LIMIT was automatically appended

    def as_text_table(self) -> str:
        if not self.rows:
            return "(no rows)"
        col_widths = [
            max(len(str(self.columns[i])), *(len(str(r[i])) for r in self.rows))
            for i in range(len(self.columns))
        ]
        sep = "+" + "+".join("-" * (w + 2) for w in col_widths) + "+"
        header = (
            "|"
            + "|".join(f" {self.columns[i]:<{col_widths[i]}} " for i in range(len(self.columns)))
            + "|"
        )
        rows_fmt = [
            "|"
            + "|".join(f" {str(r[i]):<{col_widths[i]}} " for i in range(len(self.columns)))
            + "|"
            for r in self.rows
        ]
        return "\n".join([sep, header, sep, *rows_fmt, sep])


# ---------------------------------------------------------------------------
# Conversation / agent models
# ---------------------------------------------------------------------------


@dataclass
class AgentTurn:
    role: str  # "user" | "assistant" | "tool_result"
    content: str


@dataclass
class AgentSession:
    question: str
    history: list[AgentTurn] = field(default_factory=list)
    iterations: int = 0
    final_answer: str | None = None
    status: QueryStatus = QueryStatus.SUCCESS
