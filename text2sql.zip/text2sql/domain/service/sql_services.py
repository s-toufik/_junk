"""
Domain services — pure business logic, no I/O.
"""

from __future__ import annotations

import re

from domain.model.models import SqlQuery


# ---------------------------------------------------------------------------
# SQL Validation Service
# ---------------------------------------------------------------------------

_DANGEROUS_KEYWORDS = re.compile(
    r"\b(INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|TRUNCATE|REPLACE|MERGE"
    r"|ATTACH|DETACH|PRAGMA|VACUUM|REINDEX|ANALYZE)\b",
    re.IGNORECASE,
)

_ALLOWED_LEADING = re.compile(r"^\s*(SELECT|EXPLAIN)\b", re.IGNORECASE)

_COMMENT_STRIP = re.compile(r"(--[^\n]*|/\*.*?\*/)", re.DOTALL)


class SqlValidationError(Exception):
    pass


class SqlValidationService:
    """
    Validates that a generated SQL string is safe to execute.

    Rules
    -----
    1. Must start with SELECT or EXPLAIN (after stripping comments).
    2. Must not contain write/DDL keywords anywhere in the statement.
    3. Must not be blank.
    """

    def validate(self, raw_sql: str) -> SqlQuery:
        if not raw_sql or not raw_sql.strip():
            raise SqlValidationError("Empty SQL statement.")

        # Strip comments before analysis
        clean = _COMMENT_STRIP.sub(" ", raw_sql).strip()

        if not _ALLOWED_LEADING.match(clean):
            raise SqlValidationError(
                f"Only SELECT and EXPLAIN statements are allowed. Got: {clean[:80]!r}"
            )

        if match := _DANGEROUS_KEYWORDS.search(clean):
            raise SqlValidationError(
                f"Forbidden keyword '{match.group()}' found in statement."
            )

        return SqlQuery(raw=raw_sql)


# ---------------------------------------------------------------------------
# Limit Injection Service
# ---------------------------------------------------------------------------

_HAS_LIMIT = re.compile(r"\bLIMIT\b", re.IGNORECASE)


class LimitInjectionService:
    """
    Appends a LIMIT clause to SELECT statements that don't already have one.
    """

    def __init__(self, default_limit: int = 100) -> None:
        self._limit = default_limit

    def apply(self, query: SqlQuery) -> tuple[SqlQuery, bool]:
        """
        Returns (possibly-modified query, was_limit_added).
        EXPLAIN statements are left untouched.
        """
        sql = query.normalised
        if re.match(r"^\s*EXPLAIN\b", sql, re.IGNORECASE):
            return query, False

        if _HAS_LIMIT.search(sql):
            return query, False

        new_sql = f"{sql} LIMIT {self._limit}"
        return SqlQuery(raw=new_sql), True
