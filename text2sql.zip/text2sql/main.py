#!/usr/bin/env python3
"""
Entry point for the Text-to-SQL agent.

Usage
-----
# Interactive REPL (seeds demo.db on first run):
python main.py

# Single-shot question:
python main.py "Which employees earn more than 90 000 ?"

Environment variables
---------------------
ANTHROPIC_API_KEY     (required)
TEXT2SQL_DB_PATH      path to SQLite file         [default: demo.db]
TEXT2SQL_MAX_ITERATIONS                           [default: 10]
TEXT2SQL_DEFAULT_LIMIT                            [default: 100]
TEXT2SQL_MODEL        Anthropic model name         [default: claude-sonnet-4-6]
"""

import logging
import sys

logging.basicConfig(
    level=logging.WARNING,
    format="%(levelname)s %(name)s — %(message)s",
)

from bootstrap.container import Container


def main() -> int:
    container = Container.from_env(seed_demo_db=True)

    if len(sys.argv) > 1:
        question = " ".join(sys.argv[1:])
        return container.cli_adapter.run_once(question)
    else:
        container.cli_adapter.run_repl()
        return 0


if __name__ == "__main__":
    sys.exit(main())
