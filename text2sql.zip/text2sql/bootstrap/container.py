"""
Bootstrap / DI container.

Wires together every layer of the hexagon:
  infrastructure → outbound adapters → domain services → use case → inbound adapter

Usage
-----
from bootstrap.container import Container

container = Container.from_env()   # reads ANTHROPIC_API_KEY, TEXT2SQL_DB_PATH
container.cli_adapter.run_repl()
"""

from __future__ import annotations

import os
from functools import cached_property

from adapter.inbound.cli_adapter import CliAdapter
from adapter.outbound.anthropic_llm_adapter import AnthropicLlmAdapter
from adapter.outbound.sqlite_adapters import SqliteConnectionFactory, SqliteQueryExecutor, SqliteSchemaRepository
from application.usecase.ask_question import AskQuestionUseCase
from domain.service.sql_services import LimitInjectionService, SqlValidationService
from infrastructure.seed_db import seed


class Container:
    def __init__(
        self,
        db_path: str,
        anthropic_api_key: str,
        model: str = "claude-sonnet-4-6",
        default_limit: int = 100,
        max_iterations: int = 10,
        seed_demo_db: bool = False,
    ) -> None:
        self._db_path = db_path
        self._api_key = anthropic_api_key
        self._model = model
        self._default_limit = default_limit
        self._max_iterations = max_iterations

        if seed_demo_db:
            seed(db_path)

    # ------------------------------------------------------------------
    # Infrastructure
    # ------------------------------------------------------------------

    @cached_property
    def connection_factory(self) -> SqliteConnectionFactory:
        return SqliteConnectionFactory(self._db_path)

    # ------------------------------------------------------------------
    # Outbound adapters
    # ------------------------------------------------------------------

    @cached_property
    def schema_repository(self) -> SqliteSchemaRepository:
        return SqliteSchemaRepository(self.connection_factory)

    @cached_property
    def query_executor(self) -> SqliteQueryExecutor:
        return SqliteQueryExecutor(self.connection_factory)

    @cached_property
    def llm_adapter(self) -> AnthropicLlmAdapter:
        return AnthropicLlmAdapter(api_key=self._api_key, model=self._model)

    # ------------------------------------------------------------------
    # Domain services
    # ------------------------------------------------------------------

    @cached_property
    def validation_service(self) -> SqlValidationService:
        return SqlValidationService()

    @cached_property
    def limit_service(self) -> LimitInjectionService:
        return LimitInjectionService(default_limit=self._default_limit)

    # ------------------------------------------------------------------
    # Use case
    # ------------------------------------------------------------------

    @cached_property
    def ask_use_case(self) -> AskQuestionUseCase:
        return AskQuestionUseCase(
            schema_repo=self.schema_repository,
            query_executor=self.query_executor,
            llm=self.llm_adapter,
            validation_service=self.validation_service,
            limit_service=self.limit_service,
            max_iterations=self._max_iterations,
        )

    # ------------------------------------------------------------------
    # Inbound adapters
    # ------------------------------------------------------------------

    @cached_property
    def cli_adapter(self) -> CliAdapter:
        def _schema_summary() -> str:
            schema = self.schema_repository.load_schema()
            return schema.as_ddl_summary()

        return CliAdapter(
            use_case=self.ask_use_case,
            schema_summary_fn=_schema_summary,
        )

    # ------------------------------------------------------------------
    # Factory from environment variables
    # ------------------------------------------------------------------

    @classmethod
    def from_env(cls, seed_demo_db: bool = False) -> "Container":
        api_key = os.environ.get("ANTHROPIC_API_KEY")
        if not api_key:
            raise EnvironmentError("ANTHROPIC_API_KEY environment variable is required.")
        db_path = os.environ.get("TEXT2SQL_DB_PATH", "demo.db")
        max_iter = int(os.environ.get("TEXT2SQL_MAX_ITERATIONS", "10"))
        limit = int(os.environ.get("TEXT2SQL_DEFAULT_LIMIT", "100"))
        model = os.environ.get("TEXT2SQL_MODEL", "claude-sonnet-4-6")
        return cls(
            db_path=db_path,
            anthropic_api_key=api_key,
            model=model,
            default_limit=limit,
            max_iterations=max_iter,
            seed_demo_db=seed_demo_db,
        )
