"""
Infrastructure: creates and seeds the demo SQLite database.
Run directly:  python -m infrastructure.seed_db
"""

from __future__ import annotations

import sqlite3
from pathlib import Path

_DDL = """
CREATE TABLE IF NOT EXISTS employees (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT    NOT NULL,
    department  TEXT    NOT NULL,
    salary      REAL    NOT NULL,
    hire_date   TEXT    NOT NULL   -- ISO-8601
);

CREATE TABLE IF NOT EXISTS projects (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT    NOT NULL,
    budget      REAL    NOT NULL,
    start_date  TEXT    NOT NULL,
    end_date    TEXT
);

CREATE TABLE IF NOT EXISTS assignments (
    employee_id INTEGER NOT NULL REFERENCES employees(id),
    project_id  INTEGER NOT NULL REFERENCES projects(id),
    role        TEXT    NOT NULL,
    PRIMARY KEY (employee_id, project_id)
);
"""

_EMPLOYEES = [
    ("Alice Martin",    "Engineering",  95_000, "2020-03-15"),
    ("Bob Dupont",      "Engineering",  88_000, "2019-07-01"),
    ("Claire Petit",    "Marketing",    72_000, "2021-01-10"),
    ("David Leroy",     "HR",           65_000, "2018-11-20"),
    ("Eva Rousseau",    "Engineering", 102_000, "2017-05-30"),
    ("Frank Bernard",   "Marketing",    78_000, "2022-04-22"),
    ("Gina Moreau",     "Finance",      85_000, "2020-09-01"),
    ("Hugo Simon",      "Finance",      91_000, "2016-12-15"),
    ("Iris Laurent",    "HR",           68_000, "2023-02-28"),
    ("Jules Fontaine",  "Engineering",  97_000, "2019-03-10"),
]

_PROJECTS = [
    ("Pricelab RAG",    500_000, "2024-01-01", None),
    ("Risk Dashboard",  250_000, "2023-06-01", "2024-03-31"),
    ("HR Portal",       120_000, "2023-09-01", "2024-01-15"),
    ("Data Platform",   800_000, "2022-01-01", "2024-12-31"),
    ("Mobile App",      350_000, "2024-03-01", None),
]

_ASSIGNMENTS = [
    (1, 1, "Lead Engineer"),
    (2, 1, "Backend Dev"),
    (5, 4, "Architect"),
    (10, 4, "Backend Dev"),
    (10, 1, "DevOps"),
    (3, 5, "Marketing Lead"),
    (6, 5, "Campaign Manager"),
    (4, 3, "HR Coordinator"),
    (9, 3, "HR Analyst"),
    (7, 2, "Finance Analyst"),
    (8, 4, "Finance Lead"),
    (1, 2, "Full-Stack Dev"),
]


def seed(db_path: str = "demo.db") -> None:
    path = Path(db_path)
    conn = sqlite3.connect(path)
    conn.executescript(_DDL)

    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) FROM employees")
    if cur.fetchone()[0] == 0:
        conn.executemany(
            "INSERT INTO employees (name, department, salary, hire_date) VALUES (?,?,?,?)",
            _EMPLOYEES,
        )
        conn.executemany(
            "INSERT INTO projects (name, budget, start_date, end_date) VALUES (?,?,?,?)",
            _PROJECTS,
        )
        conn.executemany(
            "INSERT INTO assignments (employee_id, project_id, role) VALUES (?,?,?)",
            _ASSIGNMENTS,
        )
        conn.commit()
        print(f"✅ Seeded {path} with sample data.")
    else:
        print(f"ℹ  {path} already contains data — skipping seed.")
    conn.close()


if __name__ == "__main__":
    import sys
    seed(sys.argv[1] if len(sys.argv) > 1 else "demo.db")
