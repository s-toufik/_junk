from __future__ import annotations
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

import pytest
import duckdb

from project.infrastructure.database import create_connection, seed_sample_data
from project.domain.model.models import SqlResult, PythonResult, ToolDecision
from project.application.port.outbound.llm_port import LLMPort
from project.application.port.outbound.sql_port import SqlPort
from project.application.port.outbound.python_port import PythonPort


# ── Stub implementations ──────────────────────────────────────────────────────

class StubLLM(LLMPort):
    """Deterministic LLM stub: returns canned responses."""

    def __init__(self, text_resp: str = "42", json_resp: dict | None = None) -> None:
        self._text = text_resp
        self._json = json_resp or {
            "decision": "sql",
            "reasoning": "need data",
            "artifact": "SELECT * FROM sales LIMIT 5",
        }

    def complete(self, system, messages):
        return self._text

    def complete_json(self, system, messages):
        return self._json


class StubSQL(SqlPort):
    def __init__(self, rows: list[dict] | None = None) -> None:
        self._rows = rows or [{"product": "Widget A", "amount": 1200.0}]

    def execute(self, query: str) -> SqlResult:
        return SqlResult(query=query, rows=self._rows, row_count=len(self._rows))

    def get_schema(self) -> dict:
        return {"sales": ["id", "product", "region", "amount", "sale_date"]}


class StubPython(PythonPort):
    def execute(self, code, context=None):
        return PythonResult(code=code, output="output: 42", artifacts={})


# ── Fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture
def db_conn():
    conn = create_connection(":memory:")
    seed_sample_data(conn)
    yield conn
    conn.close()

@pytest.fixture
def stub_llm():
    return StubLLM()

@pytest.fixture
def stub_sql():
    return StubSQL()

@pytest.fixture
def stub_python():
    return StubPython()
