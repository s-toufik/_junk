from __future__ import annotations
import pytest

from project.domain.model.models import (
    Question, SqlResult, PythonResult, AgentStep, StepType, AnalysisResult
)
from project.domain.service.analysis_service import AnalysisService


def test_question_immutable():
    q = Question(text="What is revenue?", session_id="s1")
    with pytest.raises(Exception):
        q.text = "changed"  # type: ignore[misc]


def test_sql_result_fields():
    rows = [{"col": 1}, {"col": 2}]
    r = SqlResult(query="SELECT 1", rows=rows, row_count=2)
    assert r.row_count == 2
    assert r.rows[0]["col"] == 1


def test_python_result_artifacts():
    r = PythonResult(code="x=1", output="1", artifacts={"result": 42})
    assert r.artifacts["result"] == 42


class TestAnalysisService:
    def _make_step(self, t: StepType) -> AgentStep:
        return AgentStep(step_type=t, input="q", output="o")

    def test_build_result_basic(self):
        svc = AnalysisService()
        result = svc.build_result(
            question="Q",
            answer="A",
            steps=[self._make_step(StepType.SQL)],
        )
        assert isinstance(result, AnalysisResult)
        assert result.answer == "A"
        assert len(result.steps) == 1

    def test_summarise_steps(self):
        svc = AnalysisService()
        steps = [
            self._make_step(StepType.PLAN),
            self._make_step(StepType.SQL),
            self._make_step(StepType.ANSWER),
        ]
        summary = svc.summarise_steps(steps)
        assert "PLAN" in summary
        assert "SQL" in summary
        assert "ANSWER" in summary

    def test_build_result_empty_results(self):
        svc = AnalysisService()
        result = svc.build_result(question="Q", answer="A", steps=[])
        assert result.sql_results == []
        assert result.python_results == []
