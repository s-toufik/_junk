from __future__ import annotations
import pytest

from project.application.usecase.ask_question_usecase import AskQuestionUseCase
from project.domain.model.models import (
    Question, AnalysisResult, AgentStep, StepType, ToolDecision
)
from project.domain.service.analysis_service import AnalysisService
from project.agent.graph import build_graph


class TestAskQuestionUseCase:
    def _make_use_case(self, stub_llm, stub_sql, stub_python):
        stub_llm._json = {"decision": "direct", "reasoning": "simple", "artifact": ""}
        stub_llm._text = "The answer is 42."
        graph = build_graph(llm=stub_llm, sql=stub_sql, python=stub_python)
        return AskQuestionUseCase(graph=graph, service=AnalysisService())

    def test_returns_analysis_result(self, stub_llm, stub_sql, stub_python):
        uc = self._make_use_case(stub_llm, stub_sql, stub_python)
        q = Question(text="What is the meaning of life?", session_id="s1")
        result = uc.ask(q)
        assert isinstance(result, AnalysisResult)
        assert result.question == q.text

    def test_answer_is_populated(self, stub_llm, stub_sql, stub_python):
        uc = self._make_use_case(stub_llm, stub_sql, stub_python)
        result = uc.ask(Question(text="Q?", session_id="s2"))
        assert result.answer and len(result.answer) > 0

    def test_steps_include_plan_and_answer(self, stub_llm, stub_sql, stub_python):
        uc = self._make_use_case(stub_llm, stub_sql, stub_python)
        result = uc.ask(Question(text="Q?", session_id="s3"))
        step_types = {s.step_type for s in result.steps}
        assert StepType.PLAN in step_types
        assert StepType.ANSWER in step_types

    def test_sql_flow(self, stub_llm, stub_sql, stub_python):
        """Planner decides SQL once, then done on second plan call."""
        call_count = 0

        class PlanOnceLLM(type(stub_llm)):
            def complete_json(self, system, messages):
                nonlocal call_count
                call_count += 1
                if call_count == 1:
                    return {"decision": "sql", "reasoning": "fetch", "artifact": "SELECT * FROM sales"}
                return {"decision": "done", "reasoning": "have data", "artifact": ""}

            def complete(self, system, messages):
                return "Sales total is $9000."

        graph = build_graph(llm=PlanOnceLLM(), sql=stub_sql, python=stub_python)
        uc = AskQuestionUseCase(graph=graph, service=AnalysisService())
        result = uc.ask(Question(text="Total sales?", session_id="s4"))
        assert len(result.sql_results) == 1
        assert result.sql_results[0].row_count >= 1
