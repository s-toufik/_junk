from __future__ import annotations
import pytest

from project.agent.nodes import route, make_plan_node, make_sql_node, make_python_node, make_answer_node
from project.agent.state import AgentState
from project.domain.model.models import ToolDecision, AgentStep, StepType


def _base_state(**overrides) -> AgentState:
    state: AgentState = {
        "question": "test?",
        "session_id": "s1",
        "decision": None,
        "iteration": 0,
        "max_iterations": 6,
        "steps": [],
        "sql_results": [],
        "python_results": [],
        "last_sql_result": None,
        "last_python_result": None,
        "pending_code": None,
        "pending_query": None,
        "answer": None,
        "error": None,
    }
    state.update(overrides)  # type: ignore[typeddict-unknown-key]
    return state


# ── Route function ─────────────────────────────────────────────────────────────

class TestRoute:
    def test_routes_to_sql(self):
        assert route(_base_state(decision=ToolDecision.SQL, iteration=1)) == "sql"

    def test_routes_to_python(self):
        assert route(_base_state(decision=ToolDecision.PYTHON, iteration=1)) == "python"

    def test_routes_to_answer_on_done(self):
        assert route(_base_state(decision=ToolDecision.DONE, iteration=1)) == "answer"

    def test_routes_to_answer_on_direct(self):
        assert route(_base_state(decision=ToolDecision.DIRECT, iteration=1)) == "answer"

    def test_routes_to_answer_when_max_iter_exceeded(self):
        assert route(_base_state(decision=ToolDecision.SQL, iteration=10, max_iterations=6)) == "answer"

    def test_routes_to_plan_when_decision_none(self):
        assert route(_base_state(decision=None, iteration=1)) == "plan"


# ── Plan node ─────────────────────────────────────────────────────────────────

class TestPlanNode:
    def test_sets_pending_query_for_sql(self, stub_llm, stub_sql):
        stub_llm._json = {"decision": "sql", "reasoning": "r", "artifact": "SELECT 1"}
        node = make_plan_node(__import__("project.agent.planner", fromlist=["Planner"]).Planner(stub_llm, stub_sql))
        result = node(_base_state())
        assert result["decision"] == ToolDecision.SQL
        assert result["pending_query"] == "SELECT 1"
        assert result["iteration"] == 1
        assert len(result["steps"]) == 1

    def test_increments_iteration(self, stub_llm, stub_sql):
        from project.agent.planner import Planner
        node = make_plan_node(Planner(stub_llm, stub_sql))
        result = node(_base_state(iteration=3))
        assert result["iteration"] == 4


# ── SQL node ──────────────────────────────────────────────────────────────────

class TestSqlNode:
    def test_success_populates_sql_results(self, stub_llm, stub_sql, stub_python):
        from project.agent.executor import Executor
        executor = Executor(llm=stub_llm, sql=stub_sql, python=stub_python)
        node = make_sql_node(executor)
        result = node(_base_state(pending_query="SELECT * FROM sales"))
        assert len(result["sql_results"]) == 1
        assert result["last_sql_result"] is not None
        assert result["decision"] is None  # reset for re-plan

    def test_error_sets_done(self, stub_llm, stub_python):
        from project.agent.executor import Executor
        from project.application.port.outbound.sql_port import SqlPort

        class FailSQL(SqlPort):
            def execute(self, query): raise RuntimeError("db error")
            def get_schema(self): return {}

        executor = Executor(llm=stub_llm, sql=FailSQL(), python=stub_python)
        node = make_sql_node(executor)
        result = node(_base_state(pending_query="BAD"))
        assert result["decision"] == ToolDecision.DONE
        assert "error" in result


# ── Answer node ───────────────────────────────────────────────────────────────

class TestAnswerNode:
    def test_uses_llm_for_answer(self, stub_llm):
        stub_llm._text = "Revenue was $42M"
        node = make_answer_node(stub_llm)
        result = node(_base_state())
        assert result["answer"] == "Revenue was $42M"
        assert result["decision"] == ToolDecision.DONE

    def test_error_state_produces_error_answer(self, stub_llm):
        node = make_answer_node(stub_llm)
        result = node(_base_state(error="DB timeout"))
        assert "DB timeout" in result["answer"]
