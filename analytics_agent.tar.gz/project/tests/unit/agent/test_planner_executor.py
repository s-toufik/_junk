from __future__ import annotations
import pytest

from project.agent.planner import Planner
from project.agent.executor import Executor
from project.domain.model.models import ToolDecision, SqlResult, PythonResult
from project.application.port.outbound.llm_port import LLMPort
from project.application.port.outbound.sql_port import SqlPort
from project.application.port.outbound.python_port import PythonPort

# ── Planner tests ─────────────────────────────────────────────────────────────

class TestPlanner:
    def test_sql_decision(self, stub_llm, stub_sql):
        stub_llm._json = {
            "decision": "sql",
            "reasoning": "need data",
            "artifact": "SELECT * FROM sales",
        }
        planner = Planner(llm=stub_llm, sql=stub_sql)
        decision, reasoning, artifact = planner.plan("top products?", [])
        assert decision == ToolDecision.SQL
        assert "SELECT" in artifact

    def test_direct_decision(self, stub_llm, stub_sql):
        stub_llm._json = {
            "decision": "direct",
            "reasoning": "general knowledge",
            "artifact": "",
        }
        planner = Planner(llm=stub_llm, sql=stub_sql)
        decision, _, _ = planner.plan("What is GDP?", [])
        assert decision == ToolDecision.DIRECT

    def test_unknown_decision_defaults_to_direct(self, stub_llm, stub_sql):
        stub_llm._json = {
            "decision": "UNKNOWN_DECISION",
            "reasoning": "...",
            "artifact": "",
        }
        planner = Planner(llm=stub_llm, sql=stub_sql)
        decision, _, _ = planner.plan("?", [])
        assert decision == ToolDecision.DIRECT

    def test_bad_json_response_defaults_to_direct(self, stub_sql):
        class BadJsonLLM(LLMPort):
            def complete(self, system, messages): return "not json at all"
            def complete_json(self, system, messages): return {"decision": "direct", "reasoning": "", "artifact": ""}

        planner = Planner(llm=BadJsonLLM(), sql=stub_sql)
        decision, _, _ = planner.plan("Q", [])
        assert decision == ToolDecision.DIRECT


# ── Executor tests ────────────────────────────────────────────────────────────

class TestExecutor:
    def test_run_sql_success(self, stub_llm, stub_sql, stub_python):
        executor = Executor(llm=stub_llm, sql=stub_sql, python=stub_python)
        result = executor.run_sql("SELECT * FROM sales")
        assert isinstance(result, SqlResult)
        assert result.row_count >= 1

    def test_run_python_success(self, stub_llm, stub_sql, stub_python):
        executor = Executor(llm=stub_llm, sql=stub_sql, python=stub_python)
        result = executor.run_python("print('hello')")
        assert isinstance(result, PythonResult)
        assert "42" in result.output  # stub always returns "output: 42"

    def test_sql_retry_on_failure(self, stub_llm, stub_python):
        call_count = 0

        class FailThenSucceedSQL(SqlPort):
            def execute(self, query):
                nonlocal call_count
                call_count += 1
                if call_count < 2:
                    raise RuntimeError("syntax error")
                return SqlResult(query=query, rows=[{"x": 1}], row_count=1)

            def get_schema(self):
                return {}

        stub_llm._text = "SELECT x FROM t"  # fixed query
        executor = Executor(llm=stub_llm, sql=FailThenSucceedSQL(), python=stub_python)
        result = executor.run_sql("BADSQL")
        assert result.row_count == 1
        assert call_count == 2

    def test_sql_raises_after_max_retries(self, stub_llm, stub_python):
        class AlwaysFailSQL(SqlPort):
            def execute(self, query): raise RuntimeError("always fails")
            def get_schema(self): return {}

        stub_llm._text = "SELECT 1"
        executor = Executor(llm=stub_llm, sql=AlwaysFailSQL(), python=stub_python)
        with pytest.raises(RuntimeError, match="SQL failed"):
            executor.run_sql("BAD")
