from __future__ import annotations
import pytest
import duckdb

from project.adapter.outbound.sql_repository import DuckDBSqlAdapter
from project.adapter.outbound.python_sandbox import RestrictedPythonAdapter
from project.domain.model.models import SqlResult, PythonResult


# ── DuckDB SQL adapter ────────────────────────────────────────────────────────

class TestDuckDBSqlAdapter:
    def test_execute_returns_rows(self, db_conn):
        adapter = DuckDBSqlAdapter(db_conn)
        result = adapter.execute("SELECT * FROM sales ORDER BY id")
        assert isinstance(result, SqlResult)
        assert result.row_count == 8
        assert "product" in result.rows[0]

    def test_get_schema_includes_tables(self, db_conn):
        adapter = DuckDBSqlAdapter(db_conn)
        schema = adapter.get_schema()
        assert "sales" in schema
        assert "trades" in schema
        assert "product" in schema["sales"]

    def test_aggregate_query(self, db_conn):
        adapter = DuckDBSqlAdapter(db_conn)
        result = adapter.execute(
            "SELECT region, SUM(amount) as total FROM sales GROUP BY region ORDER BY region"
        )
        assert result.row_count == 3
        regions = {r["region"] for r in result.rows}
        assert regions == {"AMER", "APAC", "EMEA"}

    def test_invalid_query_raises(self, db_conn):
        adapter = DuckDBSqlAdapter(db_conn)
        with pytest.raises(Exception):
            adapter.execute("SELECT * FROM nonexistent_table_xyz")


# ── Python sandbox adapter ────────────────────────────────────────────────────

class TestRestrictedPythonAdapter:
    def test_simple_print(self):
        adapter = RestrictedPythonAdapter()
        result = adapter.execute("print('hello world')")
        assert "hello world" in result.output

    def test_math_computation(self):
        adapter = RestrictedPythonAdapter()
        result = adapter.execute("print(2 + 2 * 10)")
        assert "22" in result.output

    def test_context_data_accessible(self):
        adapter = RestrictedPythonAdapter()
        code = """
total = sum(row['amount'] for row in data)
print(total)
"""
        result = adapter.execute(code, context={"data": [{"amount": 100}, {"amount": 200}]})
        assert "300" in result.output

    def test_result_variable_captured(self):
        adapter = RestrictedPythonAdapter()
        result = adapter.execute("result = 42")
        assert result.artifacts.get("result") == 42

    def test_blocked_import_raises(self):
        adapter = RestrictedPythonAdapter()
        result = adapter.execute("import subprocess; subprocess.run(['ls'])")
        assert "ImportError" in result.output or "not allowed" in result.output

    def test_syntax_error_handled(self):
        adapter = RestrictedPythonAdapter()
        result = adapter.execute("def broken(: pass")
        assert "SyntaxError" in result.output

    def test_statistics_import_allowed(self):
        adapter = RestrictedPythonAdapter()
        result = adapter.execute(
            "import statistics; print(statistics.mean([1, 2, 3, 4, 5]))"
        )
        assert "3" in result.output
