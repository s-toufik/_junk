from __future__ import annotations
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "..", "src"))

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from fastapi.middleware.cors import CORSMiddleware

from project.adapter.inbound.controller import AnalyticsController
from project.application.port.inbound.ask_question import AskQuestionPort
from project.domain.model.models import (
    AnalysisResult, Question, AgentStep, StepType
)
from project.domain.service.analysis_service import AnalysisService


class StubUseCase(AskQuestionPort):
    def ask(self, question: Question) -> AnalysisResult:
        svc = AnalysisService()
        return svc.build_result(
            question=question.text,
            answer=f"Answer to: {question.text}",
            steps=[AgentStep(step_type=StepType.ANSWER, input=question.text, output="done")],
        )


@pytest.fixture
def client():
    app = FastAPI()
    controller = AnalyticsController(use_case=StubUseCase())
    controller.register(app)
    return TestClient(app)


class TestAnalyticsController:
    def test_health(self, client):
        resp = client.get("/api/v1/health")
        assert resp.status_code == 200
        assert resp.json()["status"] == "ok"

    def test_ask_returns_200(self, client):
        resp = client.post("/api/v1/ask", json={"question": "What is revenue?"})
        assert resp.status_code == 200

    def test_ask_response_shape(self, client):
        resp = client.post("/api/v1/ask", json={"question": "top products?"})
        body = resp.json()
        assert "question" in body
        assert "answer" in body
        assert "steps" in body
        assert isinstance(body["steps"], list)

    def test_ask_answer_contains_question(self, client):
        resp = client.post("/api/v1/ask", json={"question": "test question"})
        assert "test question" in resp.json()["answer"]

    def test_ask_with_explicit_session_id(self, client):
        resp = client.post(
            "/api/v1/ask",
            json={"question": "Q?", "session_id": "session-abc-123"},
        )
        assert resp.status_code == 200

    def test_ask_missing_question_returns_422(self, client):
        resp = client.post("/api/v1/ask", json={})
        assert resp.status_code == 422

    def test_ask_propagates_error_as_500(self, client):
        class FailingUseCase(AskQuestionPort):
            def ask(self, question):
                raise RuntimeError("something broke")

        app2 = FastAPI()
        AnalyticsController(use_case=FailingUseCase()).register(app2)
        c2 = TestClient(app2, raise_server_exceptions=False)
        resp = c2.post("/api/v1/ask", json={"question": "Q?"})
        assert resp.status_code == 500
