from __future__ import annotations
import os
import sys

# Make src/ importable when running as `python main.py` from project root
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "src"))

from dotenv import load_dotenv

load_dotenv()

import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from project.infrastructure.config import AppConfig
from project.infrastructure.logger import configure_logging
from project.bootstrap.container.container import Container


def create_app() -> FastAPI:
    cfg = AppConfig.from_env()
    configure_logging(cfg.log_level)

    container = Container(cfg).build()

    app = FastAPI(
        title="Analytics Agent",
        description="LangGraph ReAct agent with hexagonal architecture",
        version="1.0.0",
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )

    container.controller.register(app)

    @app.on_event("startup")
    async def _startup() -> None:
        import logging
        logging.getLogger(__name__).info("Analytics Agent started ✓")

    return app


app = create_app()

if __name__ == "__main__":
    cfg = AppConfig.from_env()
    uvicorn.run("main:app", host=cfg.host, port=cfg.port, reload=True)
