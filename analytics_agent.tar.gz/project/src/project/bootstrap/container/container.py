from __future__ import annotations

import duckdb
from openai import OpenAI

from project.infrastructure.config import AppConfig
from project.infrastructure.database import create_connection, seed_sample_data

from project.adapter.outbound.openai_client import OpenAIAdapter
from project.adapter.outbound.sql_repository import DuckDBSqlAdapter
from project.adapter.outbound.python_sandbox import RestrictedPythonAdapter
from project.adapter.inbound.controller import AnalyticsController

from project.agent.graph import build_graph
from project.application.usecase.ask_question_usecase import AskQuestionUseCase
from project.domain.service.analysis_service import AnalysisService


class Container:
    """
    Single composition root.
    Instantiates every object exactly once and wires them together.
    Nothing outside this class knows concrete types — only ports/interfaces.
    """

    def __init__(self, config: AppConfig) -> None:
        self._config = config
        self._built = False

    def build(self) -> "Container":
        cfg = self._config

        # ── Infrastructure ──────────────────────────────────────────────────
        self._db_conn: duckdb.DuckDBPyConnection = create_connection(cfg.db_path)
        seed_sample_data(self._db_conn)

        openai_client = OpenAI(api_key=cfg.openai_api_key)

        # ── Outbound adapters (implement ports) ─────────────────────────────
        self._llm = OpenAIAdapter(client=openai_client, model=cfg.openai_model)
        self._sql = DuckDBSqlAdapter(connection=self._db_conn)
        self._python = RestrictedPythonAdapter()

        # ── Agent graph ─────────────────────────────────────────────────────
        self._graph = build_graph(
            llm=self._llm,
            sql=self._sql,
            python=self._python,
        )

        # ── Domain service ──────────────────────────────────────────────────
        self._analysis_service = AnalysisService()

        # ── Use-case (implements inbound port) ──────────────────────────────
        self._use_case = AskQuestionUseCase(
            graph=self._graph,
            service=self._analysis_service,
        )

        # ── Inbound adapter ─────────────────────────────────────────────────
        self._controller = AnalyticsController(use_case=self._use_case)

        self._built = True
        return self

    @property
    def controller(self) -> AnalyticsController:
        self._assert_built()
        return self._controller

    @property
    def use_case(self) -> AskQuestionUseCase:
        self._assert_built()
        return self._use_case

    def _assert_built(self) -> None:
        if not self._built:
            raise RuntimeError("Container.build() must be called before accessing components")
