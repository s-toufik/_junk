from __future__ import annotations
import json
import logging
from typing import Any

from project.agent.state import AgentState
from project.agent.planner import Planner
from project.agent.executor import Executor
from project.application.port.outbound.llm_port import LLMPort
from project.domain.model.models import (
    AgentStep, StepType, ToolDecision, SqlResult, PythonResult
)
from project.agent.prompts import ANSWERER_SYSTEM, ANSWERER_USER

logger = logging.getLogger(__name__)


def make_plan_node(planner: Planner):
    def plan_node(state: AgentState) -> dict[str, Any]:
        history = _build_history(state)
        decision, reasoning, artifact = planner.plan(state["question"], history)

        step = AgentStep(
            step_type=StepType.PLAN,
            input=state["question"],
            output=f"decision={decision} | {reasoning}",
            metadata={"artifact": artifact},
        )

        updates: dict[str, Any] = {
            "decision": decision,
            "steps": [step],
            "iteration": state.get("iteration", 0) + 1,
        }

        if decision == ToolDecision.SQL:
            updates["pending_query"] = artifact
        elif decision == ToolDecision.PYTHON:
            updates["pending_code"] = artifact

        return updates

    return plan_node


def make_sql_node(executor: Executor):
    def sql_node(state: AgentState) -> dict[str, Any]:
        query = state.get("pending_query") or ""
        try:
            result = executor.run_sql(query)
            step = AgentStep(
                step_type=StepType.SQL,
                input=query,
                output=f"{result.row_count} rows returned",
                metadata={"sample": result.rows[:3]},
            )
            return {
                "sql_results": [result],
                "last_sql_result": result,
                "steps": [step],
                "pending_query": None,
                "decision": None,  # re-plan after each tool
            }
        except Exception as exc:
            logger.error("SQL node error: %s", exc)
            return {"error": str(exc), "decision": ToolDecision.DONE}

    return sql_node


def make_python_node(executor: Executor):
    def python_node(state: AgentState) -> dict[str, Any]:
        code = state.get("pending_code") or ""
        context: dict[str, Any] = {}

        last = state.get("last_sql_result")
        if last:
            context["data"] = last.rows

        try:
            result = executor.run_python(code, context)
            step = AgentStep(
                step_type=StepType.PYTHON,
                input=code[:200],
                output=result.output[:500],
            )
            return {
                "python_results": [result],
                "last_python_result": result,
                "steps": [step],
                "pending_code": None,
                "decision": None,
            }
        except Exception as exc:
            logger.error("Python node error: %s", exc)
            return {"error": str(exc), "decision": ToolDecision.DONE}

    return python_node


def make_answer_node(llm: LLMPort):
    def answer_node(state: AgentState) -> dict[str, Any]:
        sql_summary = _summarise_sql(state.get("sql_results", []))
        python_summary = _summarise_python(state.get("python_results", []))

        if state.get("error"):
            answer = f"An error occurred during analysis: {state['error']}"
        else:
            user_msg = ANSWERER_USER.format(
                question=state["question"],
                sql_summary=sql_summary,
                python_summary=python_summary,
            )
            answer = llm.complete(
                system=ANSWERER_SYSTEM,
                messages=[{"role": "user", "content": user_msg}],
            )

        step = AgentStep(
            step_type=StepType.ANSWER,
            input=state["question"],
            output=answer,
        )
        return {"answer": answer, "steps": [step], "decision": ToolDecision.DONE}

    return answer_node


# ── routing ────────────────────────────────────────────────────────────────────

def route(state: AgentState) -> str:
    """Central router called by LangGraph's conditional edges."""
    decision = state.get("decision")
    iteration = state.get("iteration", 0)
    max_iter = state.get("max_iterations", 6)

    if iteration >= max_iter:
        return "answer"
    if decision == ToolDecision.SQL:
        return "sql"
    if decision == ToolDecision.PYTHON:
        return "python"
    if decision in (ToolDecision.DONE, ToolDecision.DIRECT):
        return "answer"
    if decision is None:
        return "plan"  # re-plan
    return "answer"


# ── helpers ────────────────────────────────────────────────────────────────────

def _build_history(state: AgentState) -> list[dict[str, str]]:
    msgs = []
    for step in state.get("steps", []):
        msgs.append({"role": "assistant", "content": f"[{step.step_type.value}] {step.output}"})
    return msgs


def _summarise_sql(results: list[SqlResult]) -> str:
    if not results:
        return "(no SQL results)"
    parts = []
    for i, r in enumerate(results, 1):
        parts.append(f"Query {i} ({r.row_count} rows): {json.dumps(r.rows[:5], default=str)}")
    return "\n".join(parts)


def _summarise_python(results: list[PythonResult]) -> str:
    if not results:
        return "(no Python output)"
    return "\n".join(r.output for r in results)
