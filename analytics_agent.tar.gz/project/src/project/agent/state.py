from __future__ import annotations
from typing import Any, Annotated
from typing_extensions import TypedDict
import operator

from project.domain.model.models import AgentStep, SqlResult, PythonResult, ToolDecision


class AgentState(TypedDict):
    # Core
    question: str
    session_id: str

    # Routing
    decision: ToolDecision | None
    iteration: int
    max_iterations: int

    # Accumulate steps with LangGraph reducer
    steps: Annotated[list[AgentStep], operator.add]
    sql_results: Annotated[list[SqlResult], operator.add]
    python_results: Annotated[list[PythonResult], operator.add]

    # Working memory
    last_sql_result: SqlResult | None
    last_python_result: PythonResult | None
    pending_code: str | None
    pending_query: str | None

    # Output
    answer: str | None
    error: str | None
