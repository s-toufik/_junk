from __future__ import annotations

from langgraph.graph import StateGraph, END

from project.agent.state import AgentState
from project.agent.planner import Planner
from project.agent.executor import Executor
from project.agent.nodes import (
    make_plan_node,
    make_sql_node,
    make_python_node,
    make_answer_node,
    route,
)
from project.application.port.outbound.llm_port import LLMPort
from project.application.port.outbound.sql_port import SqlPort
from project.application.port.outbound.python_port import PythonPort


def build_graph(llm: LLMPort, sql: SqlPort, python: PythonPort):
    """
    Assembles and compiles the LangGraph ReAct agent.
    All dependencies injected — the graph itself has no imports from adapters.
    """
    planner = Planner(llm=llm, sql=sql)
    executor = Executor(llm=llm, sql=sql, python=python)

    plan_node = make_plan_node(planner)
    sql_node = make_sql_node(executor)
    python_node = make_python_node(executor)
    answer_node = make_answer_node(llm)

    builder = StateGraph(AgentState)

    builder.add_node("plan", plan_node)
    builder.add_node("sql", sql_node)
    builder.add_node("python", python_node)
    builder.add_node("answer", answer_node)

    builder.set_entry_point("plan")

    # After planning, route to the right tool (or answer directly)
    builder.add_conditional_edges("plan", route, {
        "sql": "sql",
        "python": "python",
        "answer": "answer",
        "plan": "plan",
    })

    # After SQL → re-plan (may fetch more data, run python, or answer)
    builder.add_conditional_edges("sql", route, {
        "plan": "plan",
        "python": "python",
        "answer": "answer",
        "sql": "sql",
    })

    # After Python → re-plan or answer
    builder.add_conditional_edges("python", route, {
        "plan": "plan",
        "sql": "sql",
        "answer": "answer",
        "python": "python",
    })

    builder.add_edge("answer", END)

    return builder.compile()
