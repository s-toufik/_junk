from __future__ import annotations
import logging
from typing import Any

from project.application.port.outbound.llm_port import LLMPort
from project.application.port.outbound.sql_port import SqlPort
from project.application.port.outbound.python_port import PythonPort
from project.domain.model.models import SqlResult, PythonResult
from project.agent.prompts import SQL_FIXER_SYSTEM, SQL_FIXER_USER

logger = logging.getLogger(__name__)

MAX_RETRIES = 2


class Executor:
    def __init__(self, llm: LLMPort, sql: SqlPort, python: PythonPort) -> None:
        self._llm = llm
        self._sql = sql
        self._python = python

    def run_sql(self, query: str) -> SqlResult:
        last_error: Exception | None = None
        current_query = query

        for attempt in range(MAX_RETRIES + 1):
            try:
                result = self._sql.execute(current_query)
                logger.info("SQL OK — %d rows", result.row_count)
                return result
            except Exception as exc:
                last_error = exc
                logger.warning("SQL attempt %d failed: %s", attempt + 1, exc)
                if attempt < MAX_RETRIES:
                    current_query = self._fix_sql(current_query, str(exc))

        raise RuntimeError(f"SQL failed after {MAX_RETRIES + 1} attempts: {last_error}") from last_error

    def run_python(self, code: str, context: dict[str, Any] | None = None) -> PythonResult:
        result = self._python.execute(code, context)
        logger.info("Python executed — output length %d", len(result.output))
        return result

    def _fix_sql(self, query: str, error: str) -> str:
        fixed = self._llm.complete(
            system=SQL_FIXER_SYSTEM,
            messages=[{"role": "user", "content": SQL_FIXER_USER.format(query=query, error=error)}],
        )
        logger.info("SQL auto-fixed by LLM")
        return fixed.strip()
