from __future__ import annotations
import json
import logging
from typing import Any

from project.application.port.outbound.llm_port import LLMPort
from project.application.port.outbound.sql_port import SqlPort
from project.domain.model.models import ToolDecision
from project.agent.prompts import PLANNER_SYSTEM, PLANNER_USER

logger = logging.getLogger(__name__)


class Planner:
    def __init__(self, llm: LLMPort, sql: SqlPort) -> None:
        self._llm = llm
        self._sql = sql

    def plan(
        self,
        question: str,
        history: list[dict[str, str]],
    ) -> tuple[ToolDecision, str, str]:
        """
        Returns (decision, reasoning, artifact).
        artifact is the SQL query or Python code to run, or empty string.
        """
        schema = self._sql.get_schema()
        schema_text = "\n".join(
            f"  {tbl}({', '.join(cols)})" for tbl, cols in schema.items()
        )
        history_text = self._format_history(history)

        user_msg = PLANNER_USER.format(
            schema=schema_text,
            history=history_text,
            question=question,
        )

        raw = self._llm.complete_json(
            system=PLANNER_SYSTEM,
            messages=[{"role": "user", "content": user_msg}],
        )

        decision_str = raw.get("decision", "direct")
        reasoning = raw.get("reasoning", "")
        artifact = raw.get("artifact", "")

        try:
            decision = ToolDecision(decision_str)
        except ValueError:
            logger.warning("Unknown decision %r, defaulting to direct", decision_str)
            decision = ToolDecision.DIRECT

        logger.info("Planner → %s | %s", decision, reasoning)
        return decision, reasoning, artifact

    @staticmethod
    def _format_history(history: list[dict[str, str]]) -> str:
        if not history:
            return "(none)"
        return "\n".join(f"{m['role'].upper()}: {m['content']}" for m in history)
