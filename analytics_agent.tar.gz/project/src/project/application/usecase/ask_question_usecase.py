from __future__ import annotations
import logging

from langgraph.graph.state import CompiledStateGraph

from project.application.port.inbound.ask_question import AskQuestionPort
from project.domain.model.models import AnalysisResult, Question
from project.domain.service.analysis_service import AnalysisService

logger = logging.getLogger(__name__)

_DEFAULT_MAX_ITER = 6


class AskQuestionUseCase(AskQuestionPort):
    """
    Application use-case: wires the compiled LangGraph graph to the domain.
    This is the only class that knows about LangGraph.
    """

    def __init__(self, graph: CompiledStateGraph, service: AnalysisService) -> None:
        self._graph = graph
        self._service = service

    def ask(self, question: Question) -> AnalysisResult:
        logger.info("AskQuestionUseCase — session=%s q=%s", question.session_id, question.text)

        initial_state = {
            "question": question.text,
            "session_id": question.session_id,
            "decision": None,
            "iteration": 0,
            "max_iterations": _DEFAULT_MAX_ITER,
            "steps": [],
            "sql_results": [],
            "python_results": [],
            "last_sql_result": None,
            "last_python_result": None,
            "pending_code": None,
            "pending_query": None,
            "answer": None,
            "error": None,
        }

        final_state = self._graph.invoke(initial_state)

        return self._service.build_result(
            question=question.text,
            answer=final_state.get("answer") or "(no answer produced)",
            steps=final_state.get("steps", []),
            sql_results=final_state.get("sql_results", []),
            python_results=final_state.get("python_results", []),
        )
