from __future__ import annotations
from abc import ABC, abstractmethod
from typing import Any

from project.domain.model.models import SqlResult


class SqlPort(ABC):
    """Port for SQL query execution."""

    @abstractmethod
    def execute(self, query: str) -> SqlResult:
        ...

    @abstractmethod
    def get_schema(self) -> dict[str, list[str]]:
        """Return {table_name: [col1, col2, ...]} for all accessible tables."""
        ...
