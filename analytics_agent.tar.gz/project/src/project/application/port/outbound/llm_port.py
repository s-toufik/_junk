from __future__ import annotations
from abc import ABC, abstractmethod
from typing import Any


class LLMPort(ABC):
    """Port for language model interactions."""

    @abstractmethod
    def complete(self, system: str, messages: list[dict[str, str]]) -> str:
        ...

    @abstractmethod
    def complete_json(self, system: str, messages: list[dict[str, str]]) -> dict[str, Any]:
        ...
