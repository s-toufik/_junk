from __future__ import annotations
from abc import ABC, abstractmethod
from typing import Any

from project.domain.model.models import PythonResult


class PythonPort(ABC):
    """Port for sandboxed Python execution."""

    @abstractmethod
    def execute(self, code: str, context: dict[str, Any] | None = None) -> PythonResult:
        ...
