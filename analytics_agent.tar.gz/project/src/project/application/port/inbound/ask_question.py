from __future__ import annotations
from abc import ABC, abstractmethod

from project.domain.model.models import AnalysisResult, Question


class AskQuestionPort(ABC):
    """Primary (inbound) port: the only way external actors talk to the application."""

    @abstractmethod
    def ask(self, question: Question) -> AnalysisResult:
        ...
