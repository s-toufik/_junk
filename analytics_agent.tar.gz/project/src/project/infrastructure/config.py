from __future__ import annotations
import os
from dataclasses import dataclass, field


@dataclass(frozen=True)
class AppConfig:
    openai_api_key: str
    openai_model: str
    db_path: str
    log_level: str
    host: str
    port: int

    @classmethod
    def from_env(cls) -> "AppConfig":
        return cls(
            openai_api_key=_require("OPENAI_API_KEY"),
            openai_model=os.getenv("OPENAI_MODEL", "gpt-4o-mini"),
            db_path=os.getenv("DB_PATH", ":memory:"),
            log_level=os.getenv("LOG_LEVEL", "INFO"),
            host=os.getenv("HOST", "0.0.0.0"),
            port=int(os.getenv("PORT", "8000")),
        )


def _require(key: str) -> str:
    val = os.getenv(key)
    if not val:
        raise EnvironmentError(f"Required environment variable '{key}' is not set")
    return val
