from __future__ import annotations
import duckdb


def create_connection(db_path: str = ":memory:") -> duckdb.DuckDBPyConnection:
    conn = duckdb.connect(db_path)
    return conn


def seed_sample_data(conn: duckdb.DuckDBPyConnection) -> None:
    """Populate demo tables so the agent has something to query."""
    conn.execute("""
        CREATE TABLE IF NOT EXISTS sales (
            id INTEGER PRIMARY KEY,
            product VARCHAR,
            region VARCHAR,
            amount DOUBLE,
            sale_date DATE
        )
    """)
    conn.execute("""
        INSERT INTO sales VALUES
            (1, 'Widget A', 'EMEA',  1200.0, '2024-01-15'),
            (2, 'Widget B', 'APAC',   850.0, '2024-01-20'),
            (3, 'Widget A', 'AMER',  2100.0, '2024-02-03'),
            (4, 'Widget C', 'EMEA',   400.0, '2024-02-14'),
            (5, 'Widget B', 'AMER',  1750.0, '2024-03-01'),
            (6, 'Widget A', 'APAC',   990.0, '2024-03-10'),
            (7, 'Widget C', 'AMER',   620.0, '2024-04-05'),
            (8, 'Widget B', 'EMEA',  1100.0, '2024-04-22')
        ON CONFLICT DO NOTHING
    """)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS trades (
            id INTEGER PRIMARY KEY,
            ticker VARCHAR,
            quantity INTEGER,
            price DOUBLE,
            trade_date DATE
        )
    """)
    conn.execute("""
        INSERT INTO trades VALUES
            (1, 'AAPL', 100, 182.5, '2024-01-10'),
            (2, 'MSFT',  50, 376.2, '2024-01-12'),
            (3, 'AAPL', 200, 188.0, '2024-02-05'),
            (4, 'NVDA',  30, 612.4, '2024-02-20'),
            (5, 'MSFT',  75, 401.5, '2024-03-15'),
            (6, 'NVDA',  60, 788.0, '2024-04-01')
        ON CONFLICT DO NOTHING
    """)
