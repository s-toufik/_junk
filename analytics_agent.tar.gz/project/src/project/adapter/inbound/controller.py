from __future__ import annotations
import uuid
from typing import Any

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from project.application.port.inbound.ask_question import AskQuestionPort
from project.domain.model.models import Question

router = APIRouter(prefix="/api/v1", tags=["analytics"])


# ── Request / Response schemas (Pydantic ONLY in the adapter layer) ─────────

class AskRequest(BaseModel):
    question: str
    session_id: str | None = None


class StepOut(BaseModel):
    step_type: str
    input: str
    output: str


class AskResponse(BaseModel):
    question: str
    answer: str
    steps: list[StepOut]
    sql_row_counts: list[int]
    python_outputs: list[str]


# ── Controller ───────────────────────────────────────────────────────────────

class AnalyticsController:
    """
    Primary (inbound) adapter: HTTP boundary.
    Translates HTTP ↔ domain types; never passes Pydantic objects deeper.
    """

    def __init__(self, use_case: AskQuestionPort) -> None:
        self._use_case = use_case

    def register(self, app: Any) -> None:
        app.include_router(self._build_router())

    def _build_router(self) -> APIRouter:
        r = APIRouter(prefix="/api/v1", tags=["analytics"])

        @r.post("/ask", response_model=AskResponse)
        def ask(body: AskRequest) -> AskResponse:
            question = Question(
                text=body.question,
                session_id=body.session_id or str(uuid.uuid4()),
            )
            try:
                result = self._use_case.ask(question)
            except Exception as exc:
                raise HTTPException(status_code=500, detail=str(exc)) from exc

            return AskResponse(
                question=result.question,
                answer=result.answer,
                steps=[
                    StepOut(
                        step_type=s.step_type.value,
                        input=s.input,
                        output=s.output,
                    )
                    for s in result.steps
                ],
                sql_row_counts=[r.row_count for r in result.sql_results],
                python_outputs=[r.output for r in result.python_results],
            )

        @r.get("/health")
        def health() -> dict[str, str]:
            return {"status": "ok"}

        return r
