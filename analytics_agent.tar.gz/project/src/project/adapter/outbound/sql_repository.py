from __future__ import annotations
import logging
from typing import Any

import duckdb

from project.application.port.outbound.sql_port import SqlPort
from project.domain.model.models import SqlResult

logger = logging.getLogger(__name__)


class DuckDBSqlAdapter(SqlPort):
    """
    Secondary adapter: DuckDB implementation of SqlPort.
    Swap this for OracleSqlAdapter on production without touching the domain.
    """

    def __init__(self, connection: duckdb.DuckDBPyConnection) -> None:
        self._conn = connection

    def execute(self, query: str) -> SqlResult:
        logger.debug("SQL → %s", query[:200])
        rel = self._conn.execute(query)
        columns = [d[0] for d in rel.description]
        raw_rows = rel.fetchall()
        rows = [dict(zip(columns, row)) for row in raw_rows]
        return SqlResult(query=query, rows=rows, row_count=len(rows))

    def get_schema(self) -> dict[str, list[str]]:
        result = self._conn.execute(
            "SELECT table_name, column_name FROM information_schema.columns ORDER BY table_name, ordinal_position"
        ).fetchall()
        schema: dict[str, list[str]] = {}
        for table, col in result:
            schema.setdefault(table, []).append(col)
        return schema
