from __future__ import annotations
import json
import logging
from typing import Any

from openai import OpenAI

from project.application.port.outbound.llm_port import LLMPort

logger = logging.getLogger(__name__)


class OpenAIAdapter(LLMPort):
    """Secondary adapter: wraps the OpenAI client behind LLMPort."""

    def __init__(self, client: OpenAI, model: str = "gpt-4o-mini") -> None:
        self._client = client
        self._model = model

    def complete(self, system: str, messages: list[dict[str, str]]) -> str:
        all_msgs = [{"role": "system", "content": system}] + messages
        resp = self._client.chat.completions.create(
            model=self._model,
            messages=all_msgs,  # type: ignore[arg-type]
            temperature=0,
        )
        content = resp.choices[0].message.content or ""
        logger.debug("LLM response (%d chars)", len(content))
        return content

    def complete_json(self, system: str, messages: list[dict[str, str]]) -> dict[str, Any]:
        raw = self.complete(system, messages)
        # Strip markdown fences if present
        text = raw.strip()
        if text.startswith("```"):
            text = text.split("\n", 1)[-1]
            text = text.rsplit("```", 1)[0]
        try:
            return json.loads(text)
        except json.JSONDecodeError as exc:
            logger.error("JSON parse failed: %s\nRaw: %s", exc, raw[:200])
            return {"decision": "direct", "reasoning": "parse error", "artifact": ""}
