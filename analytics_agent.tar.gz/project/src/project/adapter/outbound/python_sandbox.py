from __future__ import annotations
import logging
import traceback
from typing import Any

from RestrictedPython import compile_restricted, safe_builtins, safe_globals
from RestrictedPython.PrintCollector import PrintCollector

from project.application.port.outbound.python_port import PythonPort
from project.domain.model.models import PythonResult

logger = logging.getLogger(__name__)

_ALLOWED_IMPORTS = frozenset({
    "json", "math", "statistics", "datetime", "collections",
    "itertools", "functools", "operator", "pandas", "numpy",
})


def _safe_import(name: str, globals=None, locals=None, fromlist=(), level=0) -> Any:
    root = name.split(".")[0]
    if root not in _ALLOWED_IMPORTS:
        raise ImportError(f"Import of '{name}' is not allowed in the sandbox")
    import importlib
    return importlib.import_module(name)


_SANDBOX_BUILTINS: dict[str, Any] = dict(safe_builtins)
_SANDBOX_BUILTINS.update({
    "__import__": _safe_import,
    "sum": sum, "min": min, "max": max, "abs": abs, "round": round,
    "sorted": sorted, "reversed": reversed, "enumerate": enumerate,
    "zip": zip, "map": map, "filter": filter,
    "list": list, "dict": dict, "set": set, "tuple": tuple,
    "len": len, "range": range,
    "str": str, "int": int, "float": float, "bool": bool,
    "isinstance": isinstance, "issubclass": issubclass,
    "hasattr": hasattr, "getattr": getattr, "type": type,
})


def _inplace_var(op: str, x: Any, y: Any) -> Any:
    import operator as op_module
    ops = {"+=": op_module.iadd, "-=": op_module.isub, "*=": op_module.imul,
           "/=": op_module.itruediv, "//=": op_module.ifloordiv, "%=": op_module.imod}
    fn = ops.get(op)
    if fn is None:
        raise NotImplementedError(f"In-place operator {op} not supported")
    return fn(x, y)


class RestrictedPythonAdapter(PythonPort):
    """
    Secondary adapter: executes untrusted Python inside a RestrictedPython sandbox.

    RestrictedPython rewrites `print(x)` into:
        _print = _print_(_getattr_)   ← factory called with _getattr_
        _print._call_print(x)

    After exec, output is in glb['_print'].txt (list of str fragments).
    """

    def execute(self, code: str, context: dict[str, Any] | None = None) -> PythonResult:
        artifacts: dict[str, Any] = {}

        glb: dict[str, Any] = {
            **safe_globals,
            "__builtins__": _SANDBOX_BUILTINS,
            # Factory: called as _print_(_getattr_) once per scope
            "_print_": lambda _ga: PrintCollector(_getattr_=_ga),
            "_getiter_": iter,
            "_getitem_": lambda obj, key: obj[key],
            "_getattr_": getattr,
            "_write_": lambda x: x,
            "_inplacevar_": _inplace_var,
        }

        if context:
            glb.update(context)

        try:
            byte_code = compile_restricted(code, filename="<sandbox>", mode="exec")
        except SyntaxError as exc:
            return PythonResult(code=code, output=f"SyntaxError: {exc}", artifacts={})

        try:
            exec(byte_code, glb)  # noqa: S102
            # After exec, RestrictedPython stored the PrintCollector in _print
            collector: PrintCollector | None = glb.get("_print")
            output = "".join(collector.txt) if collector else ""
            if "result" in glb:
                artifacts["result"] = glb["result"]
        except Exception:
            output = traceback.format_exc()

        logger.debug("Sandbox output (%d chars): %s", len(output), output[:200])
        return PythonResult(code=code, output=output, artifacts=artifacts)
