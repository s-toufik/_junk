from __future__ import annotations
from project.domain.model.models import AnalysisResult, AgentStep, StepType


class AnalysisService:
    """Pure domain logic: assembles a final AnalysisResult from raw agent outputs."""

    def build_result(
        self,
        question: str,
        answer: str,
        steps: list[AgentStep],
        sql_results=None,
        python_results=None,
    ) -> AnalysisResult:
        return AnalysisResult(
            question=question,
            answer=answer,
            steps=steps,
            sql_results=sql_results or [],
            python_results=python_results or [],
        )

    def summarise_steps(self, steps: list[AgentStep]) -> str:
        lines = []
        for i, s in enumerate(steps, 1):
            lines.append(f"{i}. [{s.step_type.value.upper()}] {s.input[:80]}")
        return "\n".join(lines)
