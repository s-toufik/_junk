from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class StepType(str, Enum):
    PLAN = "plan"
    SQL = "sql"
    PYTHON = "python"
    ANSWER = "answer"


class ToolDecision(str, Enum):
    SQL = "sql"
    PYTHON = "python"
    DIRECT = "direct"
    DONE = "done"


@dataclass(frozen=True)
class Question:
    text: str
    session_id: str


@dataclass(frozen=True)
class SqlResult:
    query: str
    rows: list[dict[str, Any]]
    row_count: int


@dataclass(frozen=True)
class PythonResult:
    code: str
    output: str
    artifacts: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class AgentStep:
    step_type: StepType
    input: str
    output: str
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class AnalysisResult:
    question: str
    answer: str
    steps: list[AgentStep]
    sql_results: list[SqlResult] = field(default_factory=list)
    python_results: list[PythonResult] = field(default_factory=list)
