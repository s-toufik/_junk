"""
domain/model.py
===============
Pure value objects for the agent domain.

No formatting, no I/O, no LangGraph, no tool logic.
All fields are immutable via frozen dataclasses or Pydantic.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Literal, Optional, Union

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Status
# ---------------------------------------------------------------------------

class QueryStatus(Enum):
    SUCCESS         = "success"
    TOOL_ERROR      = "tool_error"
    EXECUTION_ERROR = "execution_error"
    PARSE_ERROR     = "parse_error"
    ITERATION_LIMIT = "iteration_limit"
    VALIDATION_ERROR = "validation_error"


# ---------------------------------------------------------------------------
# Structured LLM decision (replaces free-text JSON parsing)
# ---------------------------------------------------------------------------

class ToolCallDecision(BaseModel):
    """LLM decided to call a tool."""
    step_type: Literal["TOOL_CALL"] = "TOOL_CALL"
    reasoning: str
    tool_name: str
    tool_args: dict[str, Any] = Field(default_factory=dict)


class AnswerDecision(BaseModel):
    """LLM decided it has enough information to answer."""
    step_type: Literal["ANSWER"] = "ANSWER"
    reasoning: str
    answer: str


# Discriminated union — routing never needs to parse strings
AgentDecision = Union[ToolCallDecision, AnswerDecision]


# ---------------------------------------------------------------------------
# Tool result — data only, no presentation
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class ToolResult:
    """
    Immutable result of a tool execution.
    Carries raw data only — formatting belongs to the presentation layer.
    """
    tool_name: str
    success:   bool
    data:      Any                   = None
    error:     Optional[str]         = None
    stdout:    Optional[str]         = None
    metadata:  dict[str, Any]        = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Final agent result
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class AgentResult:
    """Return value of AskQuestionUseCase.ask()."""
    question:          str
    final_answer:      Optional[str]
    status:            QueryStatus
    collected_results: tuple[ToolResult, ...]
    iterations:        int
