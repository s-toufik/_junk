"""
domain/formatter.py
===================
Presentation layer for ToolResult.

ToolResult is a pure data object; all rendering lives here.
Callers choose the format they need — the domain model never decides.
"""

from __future__ import annotations

from domain.model import ToolResult


class ToolResultFormatter:
    """Renders a ToolResult into human-readable text for LLM consumption."""

    def format(self, result: ToolResult) -> str:
        if not result.success:
            return f"[ERROR from {result.tool_name}] {result.error}"
        if result.data is None:
            return f"[{result.tool_name}] No data returned."
        if isinstance(result.data, list) and result.data and isinstance(result.data[0], dict):
            return self._table(result.data)
        if hasattr(result.data, "to_string"):   # pandas DataFrame
            return result.data.to_string()
        if result.stdout:
            return result.stdout.strip()
        return str(result.data)

    @staticmethod
    def _table(rows: list[dict]) -> str:
        headers = list(rows[0].keys())
        cells   = [[str(row.get(h, "")) for h in headers] for row in rows]
        widths  = [
            max(len(h), max((len(r[i]) for r in cells), default=0))
            for i, h in enumerate(headers)
        ]
        fmt  = " | ".join(f"{{:<{w}}}" for w in widths)
        sep  = "-+-".join("-" * w for w in widths)
        body = "\n".join(fmt.format(*r) for r in cells)
        return f"{fmt.format(*headers)}\n{sep}\n{body}"
