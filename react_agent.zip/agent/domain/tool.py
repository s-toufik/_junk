"""
domain/tool.py
==============
Abstract base for all agent tools.

Tools know their own schema and how to execute.
They know nothing about the agent graph, state, or LLM.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from domain.model import ToolResult


class Tool(ABC):
    """Contract every tool must satisfy."""

    @property
    @abstractmethod
    def name(self) -> str:
        """Unique tool identifier used by the LLM."""

    @property
    @abstractmethod
    def description(self) -> str:
        """Human-readable description of what this tool does."""

    @property
    @abstractmethod
    def parameters(self) -> dict[str, Any]:
        """JSON Schema for the tool's input parameters."""

    @abstractmethod
    def execute(self, **kwargs: Any) -> ToolResult:
        """Execute the tool and return a ToolResult."""

    def schema(self) -> dict[str, Any]:
        """OpenAI-compatible function schema for LLM structured output."""
        return {
            "type": "function",
            "function": {
                "name":        self.name,
                "description": self.description,
                "parameters":  self.parameters,
            },
        }
