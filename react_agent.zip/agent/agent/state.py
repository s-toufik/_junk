"""
agent/state.py
==============
LangGraph typed state for the ReAct agent.

Design rules:
  - `decision` is the single source of truth for routing.
    It is set by the PlannerNode after every LLM call.
    The router reads only this field — never message content.
  - `messages` is append-only (add_messages reducer).
    It is the LLM conversation history, not a control channel.
  - `status` is the terminal classification written once on exit.
  - There is no `final_answer` field — the answer lives inside
    `decision` (an AnswerDecision) to avoid dual sources of truth.
"""

from __future__ import annotations

from typing import Annotated, Optional

from langgraph.graph.message import add_messages
from typing_extensions import TypedDict

from domain.model import AgentDecision, QueryStatus, ToolResult


class AgentState(TypedDict):
    # ── Immutable inputs ──────────────────────────────────────────────
    question:     str   # original user question
    schema:       str   # serialised DB schema
    tool_schemas: str   # JSON tool descriptions for the system prompt

    # ── Conversation history (append-only) ───────────────────────────
    messages: Annotated[list[dict], add_messages]

    # ── Single routing source of truth ───────────────────────────────
    decision: Optional[AgentDecision]  # set by PlannerNode, read by router

    # ── Accumulated results ───────────────────────────────────────────
    collected_results: list[ToolResult]

    # ── Terminal classification (written once on graph exit) ──────────
    status: QueryStatus
