"""
agent/executor.py
=================
ExecutorNode: dispatches the tool requested in state["decision"].

Responsibilities (strictly one):
  - Read the ToolCallDecision from state["decision"]
  - Dispatch to the correct tool via the registry
  - Append the tool result summary to state["messages"]
  - Accumulate the ToolResult into state["collected_results"]

This node does NOT:
  - Call the LLM
  - Parse JSON or strings from messages
  - Make routing decisions
  - Know anything about the graph structure
"""

from __future__ import annotations

import logging
from typing import Any

from agent.state import AgentState
from domain.formatter import ToolResultFormatter
from domain.model import QueryStatus, ToolCallDecision, ToolResult
from tools.registry import ToolRegistry

log = logging.getLogger(__name__)

_formatter = ToolResultFormatter()


class ExecutorNode:
    """
    Dispatches a tool call and records the result in state.
    Single responsibility: tool execution.
    """

    def __init__(self, registry: ToolRegistry) -> None:
        self._registry = registry

    def __call__(self, state: AgentState) -> dict[str, Any]:
        decision: ToolCallDecision = state["decision"]  # type: ignore[assignment]

        tool = self._registry.get(decision.tool_name)
        if tool is None:
            error_msg = f"Unknown tool: {decision.tool_name!r}"
            log.warning(error_msg)
            error_result = ToolResult(
                tool_name=decision.tool_name,
                success=False,
                error=error_msg,
                metadata={"status": QueryStatus.TOOL_ERROR.value},
            )
            return {
                "messages":          [{"role": "user", "content": f"[TOOL ERROR] {error_msg}"}],
                "collected_results": [*state["collected_results"], error_result],
                "status":            QueryStatus.TOOL_ERROR,
            }

        log.debug("Executing tool %r with args: %s", decision.tool_name, decision.tool_args)
        result: ToolResult = tool.execute(**decision.tool_args)

        summary = f"[RESULT: {decision.tool_name}]\n{_formatter.format(result)}"
        log.debug("Tool %r success=%s", decision.tool_name, result.success)

        return {
            "messages":          [{"role": "user", "content": summary}],
            "collected_results": [*state["collected_results"], result],
            "status":            QueryStatus.SUCCESS if result.success else QueryStatus.TOOL_ERROR,
        }
