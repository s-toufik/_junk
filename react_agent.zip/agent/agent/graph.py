"""
agent/graph.py
==============
ReactGraph: wires the three nodes into a LangGraph StateGraph.

Responsibilities (strictly one):
  - Declare nodes and edges
  - Compile the graph

This class does NOT:
  - Contain any planning, execution, or routing logic
  - Know about the LLM, tools, or domain models
  - Manage state or conversation history

Graph topology:
  ┌─────────┐  TOOL_CALL   ┌─────┐       ┌──────┐
  │ planner │ ──────────→  │ act │ ──→   │ plan │
  │         │  ANSWER      └─────┘       └──────┘
  │         │ ──────────→  END
  └─────────┘
"""

from __future__ import annotations

from langgraph.graph import END, StateGraph

from agent.executor import ExecutorNode
from agent.planner import PlannerNode
from agent.router import route_after_plan
from agent.state import AgentState


class ReactGraph:
    """
    Assembles the ReAct graph from injected node instances.
    Exposes only the compiled graph via the `compiled` property.
    """

    def __init__(self, planner: PlannerNode, executor: ExecutorNode) -> None:
        self._compiled = self._build(planner, executor)

    @property
    def compiled(self):
        return self._compiled

    @staticmethod
    def _build(planner: PlannerNode, executor: ExecutorNode):
        builder = StateGraph(AgentState)

        builder.add_node("plan", planner)
        builder.add_node("act",  executor)

        builder.set_entry_point("plan")

        # After planning: route to "act" or END based on decision type
        builder.add_conditional_edges(
            "plan",
            route_after_plan,
            {"act": "act", "end": END},
        )

        # After acting: always return to planner
        builder.add_edge("act", "plan")

        return builder.compile()
