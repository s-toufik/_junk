"""
agent/router.py
===============
Pure routing function for the LangGraph conditional edges.

Contract:
  - Reads ONLY state["decision"] — a typed AgentDecision set by PlannerNode
  - Returns a string node name: "act" | "end"
  - No JSON parsing, no regex, no message inspection
  - Deterministic: same state always yields same route

After ExecutorNode runs, the graph unconditionally returns to "plan".
That edge is wired statically in graph.py — no routing function needed.
"""

from __future__ import annotations

from domain.model import AnswerDecision, QueryStatus, ToolCallDecision
from agent.state import AgentState


def route_after_plan(state: AgentState) -> str:
    """
    Called after PlannerNode.

    AnswerDecision  → "end"   (graph terminates)
    ToolCallDecision → "act"  (ExecutorNode runs)
    Anything else   → "end"   (safety fallback)
    """
    decision = state.get("decision")

    if isinstance(decision, AnswerDecision):
        return "end"

    if isinstance(decision, ToolCallDecision):
        return "act"

    # Defensive: should never happen if PlannerNode is correct
    return "end"
