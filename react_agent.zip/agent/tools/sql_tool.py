"""
tools/sql_tool.py
=================
SQL tool with AST-based query manipulation via sqlglot.

Safety guarantees:
  - AST-level validation: only SELECT statements are allowed
  - AST-level LIMIT injection: no regex string surgery
  - Parameterised execution via the QueryExecutor port
  - Hard row cap enforced at AST level, not string level
"""

from __future__ import annotations

import logging
from typing import Any, Optional

import sqlglot
import sqlglot.expressions as exp

from domain.model import QueryStatus, ToolResult
from domain.tool import Tool

log = logging.getLogger(__name__)

# Ports — imported from your hexagonal boundary
from application.port.outbound.ports import QueryExecutor, SchemaRepository


class SqlValidationError(ValueError):
    pass


class SqlTool(Tool):
    """
    Executes validated SELECT queries with AST-level LIMIT enforcement.

    No regex. No string manipulation of SQL.
    All transformations go through the sqlglot AST.
    """

    _DEFAULT_LIMIT = 100
    _MAX_LIMIT     = 10_000

    def __init__(
        self,
        executor:    QueryExecutor,
        schema_repo: SchemaRepository,
        dialect:     str = "sqlite",
        max_limit:   int = _MAX_LIMIT,
    ) -> None:
        self._executor    = executor
        self._schema_repo = schema_repo
        self._dialect     = dialect
        self._max_limit   = max_limit

    # ------------------------------------------------------------------
    # Tool contract
    # ------------------------------------------------------------------

    @property
    def name(self) -> str:
        return "sql"

    @property
    def description(self) -> str:
        return (
            "Execute a read-only SELECT query against the database. "
            "Returns rows as a list of dicts. Use `limit` to control result size."
        )

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "sql": {
                    "type":        "string",
                    "description": "A valid SELECT statement.",
                },
                "limit": {
                    "type":        "integer",
                    "minimum":     1,
                    "maximum":     self._max_limit,
                    "description": f"Maximum rows to return (default {self._DEFAULT_LIMIT}).",
                },
                "offset": {
                    "type":        "integer",
                    "minimum":     0,
                    "description": "Pagination offset (default 0).",
                },
            },
            "required": ["sql"],
        }

    # ------------------------------------------------------------------
    # Execution
    # ------------------------------------------------------------------

    def execute(self, **kwargs: Any) -> ToolResult:
        raw_sql: str      = kwargs.get("sql", "")
        limit:   int      = min(kwargs.get("limit", self._DEFAULT_LIMIT), self._max_limit)
        offset:  int      = kwargs.get("offset", 0)

        try:
            final_sql = self._build_safe_query(raw_sql, limit, offset)
        except SqlValidationError as exc:
            return ToolResult(
                tool_name=self.name,
                success=False,
                error=str(exc),
                metadata={"status": QueryStatus.VALIDATION_ERROR.value},
            )

        try:
            result = self._executor.execute(final_sql)
        except Exception as exc:
            log.exception("SQL execution failed: %s", final_sql)
            return ToolResult(
                tool_name=self.name,
                success=False,
                error=f"Database error: {exc}",
                metadata={"status": QueryStatus.EXECUTION_ERROR.value, "sql": final_sql},
            )

        data = result.rows if hasattr(result, "rows") else result
        return ToolResult(
            tool_name=self.name,
            success=True,
            data=data,
            metadata={
                "sql":       final_sql,
                "row_count": len(data) if isinstance(data, list) else None,
            },
        )

    # ------------------------------------------------------------------
    # AST manipulation — no string surgery
    # ------------------------------------------------------------------

    def _build_safe_query(self, raw_sql: str, limit: int, offset: int) -> str:
        """
        Parse → validate → inject LIMIT/OFFSET → generate SQL.
        All transformations are AST-level.
        """
        try:
            statements = sqlglot.parse(raw_sql, dialect=self._dialect)
        except sqlglot.errors.ParseError as exc:
            raise SqlValidationError(f"Parse error: {exc}") from exc

        if len(statements) != 1:
            raise SqlValidationError("Exactly one SQL statement is required.")

        stmt = statements[0]

        if not isinstance(stmt, exp.Select):
            raise SqlValidationError(
                f"Only SELECT statements are permitted, got: {type(stmt).__name__}."
            )

        # Enforce LIMIT via AST — replaces any existing LIMIT/OFFSET
        stmt = stmt.limit(limit)
        if offset:
            stmt = stmt.offset(offset)

        return stmt.sql(dialect=self._dialect)
