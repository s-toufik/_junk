"""
tools/python_tool.py
====================
Python execution tool with subprocess-level sandboxing.

Security model:
  - Code runs in a child process, fully isolated from the agent process
  - Hard wall-clock timeout enforced by subprocess.run(timeout=...)
  - Memory cap via resource.setrlimit in the child's preexec_fn (Linux)
  - No filesystem writes outside /tmp in the child process
  - stdout/stderr captured; the parent never evals the child's output
  - Allowed imports are passed as an explicit allowlist env variable;
    the child's __import__ hook enforces it

The child runner script is embedded as a string constant and written to
a temp file per-execution — no persistent state between calls.
"""

from __future__ import annotations

import json
import logging
import os
import subprocess
import sys
import tempfile
import textwrap
from typing import Any

from domain.model import QueryStatus, ToolResult
from domain.tool import Tool

log = logging.getLogger(__name__)

# Modules the LLM is allowed to import inside the sandbox
_ALLOWLIST: frozenset[str] = frozenset({
    "math", "statistics", "datetime", "re", "json",
    "collections", "itertools", "functools",
    "pandas", "numpy", "matplotlib",
})

# Child process runner — executed in a fresh interpreter
_RUNNER_TEMPLATE = textwrap.dedent("""\
    import sys, json, importlib, builtins

    ALLOWLIST = set({allowlist!r})

    _real_import = builtins.__import__
    def _safe_import(name, *args, **kwargs):
        root = name.split(".")[0]
        if root not in ALLOWLIST:
            raise ImportError(f"Import of '{{name}}' is not permitted in this sandbox.")
        return _real_import(name, *args, **kwargs)
    builtins.__import__ = _safe_import

    _globals = {{
        "__builtins__": builtins,
        "pd":  importlib.import_module("pandas")  if "pandas"  in ALLOWLIST else None,
        "np":  importlib.import_module("numpy")   if "numpy"   in ALLOWLIST else None,
        "plt": importlib.import_module("matplotlib.pyplot") if "matplotlib" in ALLOWLIST else None,
    }}
    _globals = {{k: v for k, v in _globals.items() if v is not None}}

    _code = {code!r}
    exec(compile(_code, "<sandbox>", "exec"), _globals)

    _result = _globals.get("result") or _globals.get("df")
    if _result is not None:
        if hasattr(_result, "to_json"):
            print(json.dumps({{"__type__": "dataframe", "data": json.loads(_result.to_json(orient="records"))}}))
        else:
            try:
                print(json.dumps({{"__type__": "value", "data": _result}}))
            except TypeError:
                print(json.dumps({{"__type__": "text", "data": str(_result)}}))
    else:
        print(json.dumps({{"__type__": "none"}}))
""")


class PythonTool(Tool):
    """
    Executes Python code in an isolated subprocess with a hard timeout.

    The child process:
      - uses a restricted __import__ hook (allowlist only)
      - writes its result as a single JSON line to stdout
      - is killed after `timeout` seconds
      - is limited to `max_memory_mb` RSS on Linux
    """

    def __init__(self, timeout: int = 10, max_memory_mb: int = 256) -> None:
        self._timeout       = timeout
        self._max_memory_mb = max_memory_mb

    # ------------------------------------------------------------------
    # Tool contract
    # ------------------------------------------------------------------

    @property
    def name(self) -> str:
        return "python"

    @property
    def description(self) -> str:
        return (
            "Execute Python for data analysis or computation. "
            f"Allowed modules: {', '.join(sorted(_ALLOWLIST))}. "
            "Assign your final value to `result`. "
            f"Hard timeout: {self._timeout}s."
        )

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "code": {
                    "type":        "string",
                    "description": "Python code to execute. Assign output to `result`.",
                }
            },
            "required": ["code"],
        }

    # ------------------------------------------------------------------
    # Execution
    # ------------------------------------------------------------------

    def execute(self, **kwargs: Any) -> ToolResult:
        code: str = kwargs.get("code", "")

        runner_src = _RUNNER_TEMPLATE.format(
            allowlist=list(_ALLOWLIST),
            code=code,
        )

        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".py", delete=False, encoding="utf-8"
        ) as tmp:
            tmp.write(runner_src)
            tmp_path = tmp.name

        try:
            proc = subprocess.run(  # noqa: S603
                [sys.executable, tmp_path],
                capture_output=True,
                text=True,
                timeout=self._timeout,
                env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"},
                preexec_fn=self._set_resource_limits if sys.platform == "linux" else None,
            )
        except subprocess.TimeoutExpired:
            return ToolResult(
                tool_name=self.name,
                success=False,
                error=f"Execution timed out after {self._timeout}s.",
                metadata={"status": QueryStatus.EXECUTION_ERROR.value},
            )
        except Exception as exc:
            return ToolResult(
                tool_name=self.name,
                success=False,
                error=f"Subprocess error: {exc}",
                metadata={"status": QueryStatus.EXECUTION_ERROR.value},
            )
        finally:
            os.unlink(tmp_path)

        if proc.returncode != 0:
            return ToolResult(
                tool_name=self.name,
                success=False,
                error=proc.stderr.strip() or f"Process exited with code {proc.returncode}.",
                stdout=proc.stdout.strip() or None,
                metadata={"status": QueryStatus.EXECUTION_ERROR.value},
            )

        return self._parse_output(proc.stdout, proc.stderr)

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _parse_output(self, raw_stdout: str, raw_stderr: str) -> ToolResult:
        """Decode the child's JSON result line into a ToolResult."""
        stdout = raw_stdout.strip()
        if not stdout:
            return ToolResult(
                tool_name=self.name,
                success=True,
                data=None,
                stdout=raw_stderr.strip() or None,
            )
        try:
            envelope = json.loads(stdout.splitlines()[-1])
        except json.JSONDecodeError:
            # stdout has user print() output but no result assignment
            return ToolResult(tool_name=self.name, success=True, data=None, stdout=stdout)

        kind = envelope.get("__type__")
        data = envelope.get("data")
        return ToolResult(
            tool_name=self.name,
            success=True,
            data=data,
            stdout=stdout if kind == "none" else None,
            metadata={"result_type": kind},
        )

    def _set_resource_limits(self) -> None:
        """Called in the child process on Linux to cap memory usage."""
        try:
            import resource  # noqa: PLC0415
            limit = self._max_memory_mb * 1024 * 1024
            resource.setrlimit(resource.RLIMIT_AS, (limit, limit))
        except Exception:  # noqa: BLE001
            pass  # non-fatal: best-effort sandboxing
