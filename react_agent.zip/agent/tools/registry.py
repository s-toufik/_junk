"""
tools/registry.py
=================
Registry for all tools available to the agent.
Pure data structure — no graph or LLM knowledge.
"""

from __future__ import annotations

from typing import Optional

from domain.tool import Tool


class ToolRegistry:
    """Holds and exposes tools by name."""

    def __init__(self) -> None:
        self._tools: dict[str, Tool] = {}

    def register(self, tool: Tool) -> "ToolRegistry":
        if tool.name in self._tools:
            raise ValueError(f"Tool '{tool.name}' is already registered.")
        self._tools[tool.name] = tool
        return self  # fluent

    def get(self, name: str) -> Optional[Tool]:
        return self._tools.get(name)

    def all(self) -> list[Tool]:
        return list(self._tools.values())

    def schemas(self) -> list[dict]:
        return [t.schema() for t in self._tools.values()]
