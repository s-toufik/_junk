"""
assembly.py
===========
Wiring example — shows how to assemble the agent from its parts.

This is the composition root. In a real hexagonal application this
would live in your infrastructure layer (e.g. a DI container or a
FastAPI lifespan hook). Nothing in the domain or agent layers imports
from here.

Expected LlmPort extension:
  Your LlmPort must expose:
      def decide(self, messages: list[dict]) -> AgentDecision
  using structured output / function calling so that the returned value
  is already a typed Pydantic model (ToolCallDecision | AnswerDecision).

  Example implementation sketch (OpenAI):
      class OpenAiLlmAdapter(LlmPort):
          def decide(self, messages):
              response = self._client.beta.chat.completions.parse(
                  model="gpt-4o",
                  messages=messages,
                  response_format=AgentDecision,   # Pydantic union
              )
              return response.choices[0].message.parsed

  For Anthropic tool_use, map the tool_use block directly to
  ToolCallDecision and text blocks to AnswerDecision.
"""

from __future__ import annotations

import json

from agent.executor import ExecutorNode
from agent.graph import ReactGraph
from agent.planner import PlannerNode
from domain.model import AgentResult
from tools.python_tool import PythonTool
from tools.registry import ToolRegistry
from tools.sql_tool import SqlTool
from use_case import AskQuestionUseCase

# ── Ports (injected from your infrastructure layer) ───────────────────
# from infrastructure.adapters import OpenAiLlmAdapter, SqliteQueryExecutor, YamlSchemaRepository


def build_use_case(
    llm,           # LlmPort implementation
    executor,      # QueryExecutor implementation
    schema_repo,   # SchemaRepository implementation
    max_iterations: int = 10,
) -> AskQuestionUseCase:
    """
    Compose the agent from its parts.
    All dependencies flow inward — the domain knows nothing about adapters.
    """

    # 1. Tools
    registry = (
        ToolRegistry()
        .register(SqlTool(executor=executor, schema_repo=schema_repo))
        .register(PythonTool(timeout=10, max_memory_mb=256))
    )

    # 2. Serialise tool schemas once (passed as a static string into state)
    tool_schemas = json.dumps(registry.schemas(), indent=2)

    # 3. Graph nodes
    planner  = PlannerNode(llm)
    executor_node = ExecutorNode(registry)

    # 4. Graph
    graph = ReactGraph(planner, executor_node)

    # 5. Use case
    return AskQuestionUseCase(
        graph=graph,
        schema_repo=schema_repo,
        tool_schemas=tool_schemas,
        max_iterations=max_iterations,
    )


# ── Example usage ─────────────────────────────────────────────────────
if __name__ == "__main__":
    # Replace with real adapter instances
    # llm         = OpenAiLlmAdapter(model="gpt-4o")
    # executor    = SqliteQueryExecutor(db_path="data.db")
    # schema_repo = YamlSchemaRepository(path="schema.yaml")

    # use_case = build_use_case(llm, executor, schema_repo)
    # result: AgentResult = use_case.ask("What is the total volume traded last week?")
    # print(result.final_answer)
    pass
