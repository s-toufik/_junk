"""
use_case.py
===========
AskQuestionUseCase: the hexagonal use-case entry point.

Responsibilities:
  - Accept a question string from the inbound port
  - Build the initial AgentState
  - Drive the compiled ReactGraph
  - Map the terminal AgentState to a typed AgentResult

This class does NOT:
  - Contain graph logic (that lives in ReactGraph)
  - Parse LLM responses (that lives in PlannerNode / LlmPort)
  - Execute tools (that lives in ExecutorNode)
  - Know about LangGraph internals
"""

from __future__ import annotations

import json
import logging

from agent.graph import ReactGraph
from agent.state import AgentState
from domain.model import AgentDecision, AgentResult, AnswerDecision, QueryStatus

log = logging.getLogger(__name__)

# Port — imported from your hexagonal boundary
from application.port.outbound.ports import SchemaRepository


class AskQuestionUseCase:
    """
    Drives the ReAct graph and returns a typed AgentResult.

    Usage:
        use_case = AskQuestionUseCase(graph, schema_repo, max_iterations=10)
        result   = use_case.ask("What is the average trade volume last week?")
    """

    def __init__(
        self,
        graph:          ReactGraph,
        schema_repo:    SchemaRepository,
        tool_schemas:   str,
        max_iterations: int = 10,
    ) -> None:
        self._graph         = graph.compiled
        self._schema_repo   = schema_repo
        self._tool_schemas  = tool_schemas
        # Each plan+act pair counts as one iteration; multiply by 2 for LangGraph steps
        self._recursion_cap = max_iterations * 2

    def ask(self, question: str) -> AgentResult:
        schema = str(self._schema_repo.load_schema())

        initial: AgentState = {
            "question":          question,
            "schema":            schema,
            "tool_schemas":      self._tool_schemas,
            "messages":          [{"role": "user", "content": question}],
            "decision":          None,
            "collected_results": [],
            "status":            QueryStatus.SUCCESS,
        }

        log.info("Starting agent for question: %r", question)
        final: AgentState = self._graph.invoke(
            initial,
            config={"recursion_limit": self._recursion_cap},
        )
        log.info("Agent finished with status: %s", final["status"])

        return self._build_result(question, final)

    @staticmethod
    def _build_result(question: str, state: AgentState) -> AgentResult:
        decision: AgentDecision | None = state.get("decision")
        final_answer: str | None = (
            decision.answer
            if isinstance(decision, AnswerDecision)
            else None
        )

        status = state.get("status", QueryStatus.SUCCESS)
        if final_answer is None and status == QueryStatus.SUCCESS:
            status = QueryStatus.ITERATION_LIMIT

        iterations = sum(
            1 for m in state["messages"]
            if m.get("role") == "assistant"
        )

        return AgentResult(
            question=question,
            final_answer=final_answer,
            status=status,
            collected_results=tuple(state["collected_results"]),
            iterations=iterations,
        )
