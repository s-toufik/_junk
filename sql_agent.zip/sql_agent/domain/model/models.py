from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class MessageRole(str, Enum):
    USER = "user"
    ASSISTANT = "assistant"
    TOOL = "tool"


@dataclass(frozen=True)
class ColumnInfo:
    name: str
    type: str
    nullable: bool
    primary_key: bool


@dataclass(frozen=True)
class TableSchema:
    name: str
    columns: tuple[ColumnInfo, ...]
    foreign_keys: tuple[str, ...]  # human-readable descriptions

    def to_ddl_hint(self) -> str:
        col_lines = ", ".join(
            f"{c.name} {c.type}{'*' if c.primary_key else ''}"
            for c in self.columns
        )
        fk_hint = (" | FK: " + "; ".join(self.foreign_keys)) if self.foreign_keys else ""
        return f"{self.name}({col_lines}){fk_hint}"


@dataclass(frozen=True)
class DatabaseSchema:
    tables: tuple[TableSchema, ...]

    def to_prompt_text(self) -> str:
        return "\n".join(t.to_ddl_hint() for t in self.tables)


@dataclass(frozen=True)
class QueryResult:
    columns: tuple[str, ...]
    rows: tuple[tuple[Any, ...], ...]
    row_count: int
    truncated: bool  # True when LIMIT was auto-applied

    def to_text(self) -> str:
        if not self.rows:
            return "(no rows returned)"
        header = " | ".join(self.columns)
        sep = "-" * len(header)
        body = "\n".join(" | ".join(str(v) for v in row) for row in self.rows)
        suffix = f"\n... (truncated to {self.row_count} rows)" if self.truncated else ""
        return f"{header}\n{sep}\n{body}{suffix}"


@dataclass(frozen=True)
class ToolCall:
    tool_name: str
    arguments: dict[str, Any]
    result: str  # serialised result or error message
    success: bool


@dataclass
class ConversationTurn:
    role: MessageRole
    content: str
    tool_calls: list[ToolCall] = field(default_factory=list)


@dataclass
class AgentState:
    turns: list[ConversationTurn] = field(default_factory=list)
    iteration: int = 0
    finished: bool = False
    final_answer: str = ""
