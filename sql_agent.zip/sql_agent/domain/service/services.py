"""
Domain services: pure business logic, no I/O.
"""
from __future__ import annotations
import re
from sql_agent.domain.model.models import QueryResult, AgentState, ConversationTurn, MessageRole

# SQL keywords that must NOT appear in a read-only query
_FORBIDDEN = re.compile(
    r"\b(INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|TRUNCATE|REPLACE|MERGE|GRANT|REVOKE|ATTACH|DETACH)\b",
    re.IGNORECASE,
)
_SELECT_START = re.compile(r"^\s*(SELECT|EXPLAIN|WITH)\b", re.IGNORECASE)
_LIMIT_RE = re.compile(r"\bLIMIT\s+\d+", re.IGNORECASE)

DEFAULT_LIMIT = 50


class SQLValidationService:
    """Validates and sanitises SQL before execution."""

    def validate(self, sql: str) -> tuple[bool, str]:
        """Returns (ok, reason). reason is empty string when ok=True."""
        if not _SELECT_START.match(sql):
            return False, "Only SELECT / EXPLAIN / WITH queries are allowed."
        match = _FORBIDDEN.search(sql)
        if match:
            return False, f"Forbidden keyword detected: {match.group().upper()}"
        return True, ""

    def enforce_limit(self, sql: str, max_rows: int = DEFAULT_LIMIT) -> tuple[str, bool]:
        """
        Appends a LIMIT clause when none is present.
        Returns (patched_sql, was_patched).
        """
        if _LIMIT_RE.search(sql):
            return sql, False
        patched = sql.rstrip().rstrip(";") + f" LIMIT {max_rows}"
        return patched, True


class ConversationMemoryService:
    """Manages in-memory conversation history."""

    def __init__(self, max_iterations: int = 15) -> None:
        self._max_iterations = max_iterations

    def add_turn(self, state: AgentState, turn: ConversationTurn) -> None:
        state.turns.append(turn)

    def increment(self, state: AgentState) -> bool:
        """Increment iteration counter. Returns False when limit is exceeded."""
        state.iteration += 1
        return state.iteration <= self._max_iterations

    def build_messages_for_llm(self, state: AgentState) -> list[dict]:
        """Convert AgentState turns into the message list expected by the LLM."""
        messages: list[dict] = []
        for turn in state.turns:
            messages.append({"role": turn.role.value, "content": turn.content})
        return messages
