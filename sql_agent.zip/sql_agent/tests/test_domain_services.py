"""
Tests for pure domain logic — no I/O, no LLM calls.
"""
import pytest
from sql_agent.domain.service.services import SQLValidationService, ConversationMemoryService
from sql_agent.domain.model.models import AgentState, ConversationTurn, MessageRole


class TestSQLValidationService:
    svc = SQLValidationService()

    # --- validate ---
    def test_select_ok(self):
        ok, reason = self.svc.validate("SELECT * FROM customers")
        assert ok
        assert reason == ""

    def test_explain_ok(self):
        ok, _ = self.svc.validate("EXPLAIN SELECT id FROM orders")
        assert ok

    def test_with_cte_ok(self):
        ok, _ = self.svc.validate("WITH t AS (SELECT 1) SELECT * FROM t")
        assert ok

    def test_insert_blocked(self):
        ok, reason = self.svc.validate("INSERT INTO customers VALUES (1,'x','x@x.com','FR')")
        assert not ok
        assert not ok  # blocked by non-SELECT start check

    def test_drop_blocked(self):
        ok, reason = self.svc.validate("DROP TABLE customers")
        assert not ok

    def test_update_blocked(self):
        ok, reason = self.svc.validate("UPDATE customers SET name='Eve' WHERE id=1")
        assert not ok

    def test_delete_blocked(self):
        ok, _ = self.svc.validate("DELETE FROM orders")
        assert not ok

    def test_inline_injection_blocked(self):
        # SELECT wrapping a hidden DROP should still be caught
        ok, reason = self.svc.validate("SELECT 1; DROP TABLE orders")
        assert not ok

    # --- enforce_limit ---
    def test_limit_appended(self):
        sql, patched = self.svc.enforce_limit("SELECT * FROM products", max_rows=10)
        assert patched
        assert "LIMIT 10" in sql

    def test_limit_not_appended_when_present(self):
        sql, patched = self.svc.enforce_limit("SELECT * FROM products LIMIT 5")
        assert not patched
        assert sql.count("LIMIT") == 1


class TestConversationMemoryService:
    def test_increment_under_limit(self):
        svc = ConversationMemoryService(max_iterations=3)
        state = AgentState()
        assert svc.increment(state)  # 1
        assert svc.increment(state)  # 2
        assert svc.increment(state)  # 3

    def test_increment_exceeds_limit(self):
        svc = ConversationMemoryService(max_iterations=2)
        state = AgentState()
        svc.increment(state)
        svc.increment(state)
        assert not svc.increment(state)  # 3 > 2

    def test_build_messages(self):
        svc = ConversationMemoryService()
        state = AgentState()
        svc.add_turn(state, ConversationTurn(role=MessageRole.USER, content="hello"))
        svc.add_turn(state, ConversationTurn(role=MessageRole.ASSISTANT, content="hi"))
        msgs = svc.build_messages_for_llm(state)
        assert msgs == [
            {"role": "user", "content": "hello"},
            {"role": "assistant", "content": "hi"},
        ]
