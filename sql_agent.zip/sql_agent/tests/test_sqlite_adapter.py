"""
Integration tests for the SQLite adapter — uses an in-memory DB.
"""
import sqlite3
import pytest
from sql_agent.adapter.outbound.sqlite_adapter import SQLiteDatabaseAdapter


@pytest.fixture()
def db_path(tmp_path):
    path = str(tmp_path / "test.db")
    conn = sqlite3.connect(path)
    conn.executescript("""
        CREATE TABLE users (
            id    INTEGER PRIMARY KEY,
            name  TEXT NOT NULL,
            age   INTEGER
        );
        CREATE TABLE posts (
            id      INTEGER PRIMARY KEY,
            user_id INTEGER NOT NULL REFERENCES users(id),
            title   TEXT NOT NULL
        );
        INSERT INTO users VALUES (1, 'Alice', 30);
        INSERT INTO users VALUES (2, 'Bob', 25);
        INSERT INTO posts VALUES (1, 1, 'Hello World');
    """)
    conn.commit()
    conn.close()
    return path


class TestSQLiteAdapter:
    def test_get_schema_returns_both_tables(self, db_path):
        adapter = SQLiteDatabaseAdapter(db_path)
        schema = adapter.get_schema()
        names = {t.name for t in schema.tables}
        assert names == {"users", "posts"}

    def test_schema_columns_detected(self, db_path):
        adapter = SQLiteDatabaseAdapter(db_path)
        schema = adapter.get_schema()
        users = next(t for t in schema.tables if t.name == "users")
        col_names = {c.name for c in users.columns}
        assert col_names == {"id", "name", "age"}

    def test_foreign_key_detected(self, db_path):
        adapter = SQLiteDatabaseAdapter(db_path)
        schema = adapter.get_schema()
        posts = next(t for t in schema.tables if t.name == "posts")
        assert any("users" in fk for fk in posts.foreign_keys)

    def test_execute_select(self, db_path):
        adapter = SQLiteDatabaseAdapter(db_path)
        result = adapter.execute_query("SELECT name FROM users ORDER BY id")
        assert result.columns == ("name",)
        assert result.rows == (("Alice",), ("Bob",))

    def test_schema_to_prompt_text(self, db_path):
        adapter = SQLiteDatabaseAdapter(db_path)
        schema = adapter.get_schema()
        text = schema.to_prompt_text()
        assert "users" in text
        assert "posts" in text
