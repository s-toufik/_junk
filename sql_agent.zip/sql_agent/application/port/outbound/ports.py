"""
Outbound ports: interfaces the application layer expects adapters to implement.
"""
from __future__ import annotations
from abc import ABC, abstractmethod
from typing import Any

from sql_agent.domain.model.models import DatabaseSchema, QueryResult


class DatabasePort(ABC):
    """Read-only access to a relational database."""

    @abstractmethod
    def get_schema(self) -> DatabaseSchema:
        ...

    @abstractmethod
    def execute_query(self, sql: str) -> QueryResult:
        ...


class LLMPort(ABC):
    """Communication with a large language model."""

    @abstractmethod
    def chat(
        self,
        system: str,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]],
    ) -> dict[str, Any]:
        """
        Returns a raw response dict with at least:
          {
            "type": "text" | "tool_use",
            "content": str,          # when type == "text"
            "tool_name": str,         # when type == "tool_use"
            "tool_input": dict,       # when type == "tool_use"
          }
        """
        ...
