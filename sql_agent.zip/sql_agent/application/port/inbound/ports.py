"""
Inbound port: what the outside world can ask the application to do.
"""
from __future__ import annotations
from abc import ABC, abstractmethod


class SQLAgentPort(ABC):
    @abstractmethod
    def run(self, user_question: str) -> str:
        """Ask a natural-language question; return a natural-language answer."""
        ...
