"""
AskQuestionUseCase — the main agentic loop.

Responsibilities:
- Build the system prompt with live schema
- Drive the Planner (LLM) → SQLExecutor → memory loop
- Enforce iteration cap and read-only constraints
- Surface errors back to the LLM for self-correction
"""
from __future__ import annotations
import json
import logging

from sql_agent.application.port.inbound.ports import SQLAgentPort
from sql_agent.application.port.outbound.ports import DatabasePort, LLMPort
from sql_agent.domain.model.models import (
    AgentState,
    ConversationTurn,
    MessageRole,
    ToolCall,
)
from sql_agent.domain.service.services import (
    ConversationMemoryService,
    SQLValidationService,
)

logger = logging.getLogger(__name__)

# --------------------------------------------------------------------------- #
# Tool definitions exposed to the LLM                                          #
# --------------------------------------------------------------------------- #
TOOLS: list[dict] = [
    {
        "name": "execute_sql",
        "description": (
            "Execute a read-only SQL SELECT query against the database. "
            "Only SELECT, EXPLAIN and CTEs (WITH …) are permitted. "
            "A LIMIT will be auto-applied if you omit one. "
            "On error the database message is returned so you can self-correct."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "sql": {
                    "type": "string",
                    "description": "A valid SQLite SELECT statement.",
                }
            },
            "required": ["sql"],
        },
    },
    {
        "name": "get_schema",
        "description": "Return the full database schema (tables, columns, types, foreign keys).",
        "input_schema": {"type": "object", "properties": {}, "required": []},
    },
]


class AskQuestionUseCase(SQLAgentPort):
    def __init__(
        self,
        db: DatabasePort,
        llm: LLMPort,
        max_iterations: int = 15,
        max_rows: int = 50,
    ) -> None:
        self._db = db
        self._llm = llm
        self._validation = SQLValidationService()
        self._memory = ConversationMemoryService(max_iterations=max_iterations)
        self._max_rows = max_rows

    # ------------------------------------------------------------------ #
    # Inbound port implementation                                          #
    # ------------------------------------------------------------------ #
    def run(self, user_question: str) -> str:
        schema = self._db.get_schema()
        system = self._build_system_prompt(schema.to_prompt_text())

        state = AgentState()
        self._memory.add_turn(
            state,
            ConversationTurn(role=MessageRole.USER, content=user_question),
        )

        while True:
            if not self._memory.increment(state):
                return (
                    f"Reached the maximum of {state.iteration - 1} iterations "
                    "without a final answer. Please rephrase your question."
                )

            messages = self._memory.build_messages_for_llm(state)
            response = self._llm.chat(system=system, messages=messages, tools=TOOLS)

            logger.debug("LLM response type=%s iter=%d", response["type"], state.iteration)

            # ── Final text answer ──────────────────────────────────────
            if response["type"] == "text":
                state.finished = True
                state.final_answer = response["content"]
                self._memory.add_turn(
                    state,
                    ConversationTurn(
                        role=MessageRole.ASSISTANT, content=response["content"]
                    ),
                )
                return state.final_answer

            # ── Tool call ──────────────────────────────────────────────
            if response["type"] == "tool_use":
                tool_name = response["tool_name"]
                tool_input = response["tool_input"]

                tool_result, success = self._dispatch_tool(tool_name, tool_input)

                tc = ToolCall(
                    tool_name=tool_name,
                    arguments=tool_input,
                    result=tool_result,
                    success=success,
                )
                assistant_turn = ConversationTurn(
                    role=MessageRole.ASSISTANT,
                    content=f"[tool_use: {tool_name}]",
                    tool_calls=[tc],
                )
                self._memory.add_turn(state, assistant_turn)

                # Feed result back as a tool message
                self._memory.add_turn(
                    state,
                    ConversationTurn(
                        role=MessageRole.TOOL,
                        content=tool_result,
                    ),
                )
                continue

            # Unknown response shape — treat as fatal
            return f"Unexpected LLM response: {response}"

    # ------------------------------------------------------------------ #
    # Private helpers                                                       #
    # ------------------------------------------------------------------ #
    def _dispatch_tool(self, name: str, args: dict) -> tuple[str, bool]:
        if name == "get_schema":
            try:
                schema = self._db.get_schema()
                return schema.to_prompt_text(), True
            except Exception as exc:
                return f"Schema error: {exc}", False

        if name == "execute_sql":
            return self._run_sql(args.get("sql", ""))

        return f"Unknown tool: {name}", False

    def _run_sql(self, sql: str) -> tuple[str, bool]:
        # 1. Validate
        ok, reason = self._validation.validate(sql)
        if not ok:
            return f"Validation error: {reason}", False

        # 2. Enforce row limit
        sql, was_patched = self._validation.enforce_limit(sql, self._max_rows)
        if was_patched:
            logger.debug("Auto-applied LIMIT %d to query", self._max_rows)

        # 3. Execute (errors returned to LLM for self-correction)
        try:
            result = self._db.execute_query(sql)
            return result.to_text(), True
        except Exception as exc:
            return f"Database error: {exc}", False

    @staticmethod
    def _build_system_prompt(schema_text: str) -> str:
        return f"""You are a helpful SQL assistant. You answer questions about data stored in a SQLite database.

DATABASE SCHEMA:
{schema_text}

RULES:
- Use the `get_schema` tool first if you are unsure about table or column names.
- Use the `execute_sql` tool to run SELECT queries. Never guess column names.
- If a query fails, read the error message and try a corrected query.
- When you have enough data to answer, reply in plain language — do not show raw SQL to the user unless asked.
- Be concise and factual.
"""
