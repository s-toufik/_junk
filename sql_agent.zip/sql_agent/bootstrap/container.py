"""
Bootstrap — dependency injection container.

Wires outbound adapters → use-case → inbound adapter.
This is the only place that imports concrete implementations.
"""
from __future__ import annotations
import os
from functools import cached_property

from sql_agent.adapter.inbound.cli_adapter import CLIAdapter
from sql_agent.adapter.outbound.anthropic_adapter import AnthropicLLMAdapter
from sql_agent.adapter.outbound.sqlite_adapter import SQLiteDatabaseAdapter
from sql_agent.application.usecase.ask_question import AskQuestionUseCase


class Container:
    def __init__(
        self,
        db_path: str = "demo.db",
        api_key: str | None = None,
        max_iterations: int = 15,
        max_rows: int = 50,
    ) -> None:
        self._db_path = db_path
        self._api_key = api_key or os.getenv("ANTHROPIC_API_KEY")
        self._max_iterations = max_iterations
        self._max_rows = max_rows

    @cached_property
    def db_adapter(self) -> SQLiteDatabaseAdapter:
        return SQLiteDatabaseAdapter(self._db_path)

    @cached_property
    def llm_adapter(self) -> AnthropicLLMAdapter:
        return AnthropicLLMAdapter(api_key=self._api_key)

    @cached_property
    def use_case(self) -> AskQuestionUseCase:
        return AskQuestionUseCase(
            db=self.db_adapter,
            llm=self.llm_adapter,
            max_iterations=self._max_iterations,
            max_rows=self._max_rows,
        )

    @cached_property
    def cli(self) -> CLIAdapter:
        return CLIAdapter(agent=self.use_case)
