"""
Creates and seeds a sample SQLite database for demonstration.
"""
from __future__ import annotations
import sqlite3
from pathlib import Path


SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS customers (
    id        INTEGER PRIMARY KEY,
    name      TEXT    NOT NULL,
    email     TEXT    UNIQUE NOT NULL,
    country   TEXT    NOT NULL
);

CREATE TABLE IF NOT EXISTS products (
    id       INTEGER PRIMARY KEY,
    name     TEXT    NOT NULL,
    category TEXT    NOT NULL,
    price    REAL    NOT NULL
);

CREATE TABLE IF NOT EXISTS orders (
    id          INTEGER PRIMARY KEY,
    customer_id INTEGER NOT NULL REFERENCES customers(id),
    created_at  TEXT    NOT NULL,
    status      TEXT    NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS order_items (
    id         INTEGER PRIMARY KEY,
    order_id   INTEGER NOT NULL REFERENCES orders(id),
    product_id INTEGER NOT NULL REFERENCES products(id),
    quantity   INTEGER NOT NULL,
    unit_price REAL    NOT NULL
);
"""

SEED_SQL = """
INSERT OR IGNORE INTO customers VALUES
  (1, 'Alice Martin',  'alice@example.com',  'France'),
  (2, 'Bob Dupont',    'bob@example.com',    'Belgium'),
  (3, 'Carol Morel',   'carol@example.com',  'France'),
  (4, 'David Leclerc', 'david@example.com',  'Switzerland');

INSERT OR IGNORE INTO products VALUES
  (1, 'Laptop Pro',    'Electronics', 1299.99),
  (2, 'Wireless Mouse','Electronics',   29.99),
  (3, 'Desk Chair',    'Furniture',   349.00),
  (4, 'Notebook A5',   'Stationery',    4.50),
  (5, 'USB-C Hub',     'Electronics',  49.99);

INSERT OR IGNORE INTO orders VALUES
  (1, 1, '2024-01-10', 'delivered'),
  (2, 2, '2024-01-15', 'delivered'),
  (3, 1, '2024-02-01', 'shipped'),
  (4, 3, '2024-02-10', 'pending'),
  (5, 4, '2024-03-05', 'delivered');

INSERT OR IGNORE INTO order_items VALUES
  (1,  1, 1, 1, 1299.99),
  (2,  1, 2, 2,   29.99),
  (3,  2, 3, 1,  349.00),
  (4,  3, 5, 3,   49.99),
  (5,  4, 4, 10,   4.50),
  (6,  5, 1, 1, 1299.99),
  (7,  5, 2, 1,   29.99);
"""


def seed(db_path: str = "demo.db") -> None:
    path = Path(db_path)
    conn = sqlite3.connect(path)
    conn.executescript(SCHEMA_SQL)
    conn.executescript(SEED_SQL)
    conn.commit()
    conn.close()
    print(f"Database seeded at {path.resolve()}")


if __name__ == "__main__":
    seed()
