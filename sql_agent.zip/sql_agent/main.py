#!/usr/bin/env python3
"""
Entry point for the SQL Agent.

Usage:
    python main.py                         # interactive REPL
    python main.py "How many customers?"   # single question
"""
import sys
import logging

from sql_agent.bootstrap.container import Container
from sql_agent.infrastructure.seed_db import seed

logging.basicConfig(level=logging.WARNING, format="%(levelname)s %(name)s: %(message)s")


def main() -> None:
    # Seed demo database if it doesn't exist
    seed("demo.db")

    container = Container(db_path="demo.db")

    if len(sys.argv) > 1:
        question = " ".join(sys.argv[1:])
        answer = container.cli.run_single(question)
        print(f"Agent: {answer}")
    else:
        container.cli.run_interactive()


if __name__ == "__main__":
    main()
