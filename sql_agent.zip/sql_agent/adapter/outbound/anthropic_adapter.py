"""
Anthropic adapter — implements LLMPort using the anthropic Python SDK.

The adapter normalises the raw Anthropic response into the simple dict
expected by the use-case so the domain never depends on the SDK types.
"""
from __future__ import annotations
import logging
from typing import Any

import anthropic

from sql_agent.application.port.outbound.ports import LLMPort

logger = logging.getLogger(__name__)

MODEL = "claude-sonnet-4-6"


class AnthropicLLMAdapter(LLMPort):
    def __init__(self, api_key: str | None = None, model: str = MODEL) -> None:
        self._client = anthropic.Anthropic(api_key=api_key)
        self._model = model

    def chat(
        self,
        system: str,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]],
    ) -> dict[str, Any]:
        # Anthropic doesn't accept "tool" as a role in messages directly —
        # we convert it to a user message wrapping a tool_result block.
        converted = self._convert_messages(messages)

        response = self._client.messages.create(
            model=self._model,
            max_tokens=4096,
            system=system,
            tools=tools,  # type: ignore[arg-type]
            messages=converted,
        )

        logger.debug("stop_reason=%s", response.stop_reason)

        # ── Tool use ──────────────────────────────────────────────────
        if response.stop_reason == "tool_use":
            for block in response.content:
                if block.type == "tool_use":
                    return {
                        "type": "tool_use",
                        "tool_name": block.name,
                        "tool_input": block.input,
                        # Keep the raw assistant message so we can replay it
                        "_raw_assistant_content": response.content,
                    }

        # ── Text answer ───────────────────────────────────────────────
        text = " ".join(
            block.text for block in response.content if hasattr(block, "text")
        )
        return {"type": "text", "content": text}

    # ------------------------------------------------------------------ #
    # Message conversion                                                   #
    # ------------------------------------------------------------------ #
    def _convert_messages(self, messages: list[dict]) -> list[dict]:
        """
        Convert internal message format to Anthropic's format.

        Anthropic requires that tool results follow an assistant message that
        contains a tool_use block.  We track the last tool_use id to wire
        the result correctly.
        """
        converted: list[dict] = []
        pending_tool_use_id: str | None = None
        pending_tool_name: str | None = None

        for msg in messages:
            role = msg["role"]
            content = msg["content"]

            if role == "user":
                converted.append({"role": "user", "content": content})
                pending_tool_use_id = None

            elif role == "assistant":
                # Plain assistant text
                if not content.startswith("[tool_use:"):
                    converted.append({"role": "assistant", "content": content})
                    pending_tool_use_id = None
                else:
                    # We need to emit an assistant message with a tool_use block.
                    # The actual tool_use block will be reconstructed with a
                    # synthetic id; the important thing is the name is preserved.
                    tool_name = content.removeprefix("[tool_use: ").removesuffix("]")
                    pending_tool_use_id = f"tool_{len(converted)}"
                    pending_tool_name = tool_name
                    converted.append({
                        "role": "assistant",
                        "content": [
                            {
                                "type": "tool_use",
                                "id": pending_tool_use_id,
                                "name": tool_name,
                                "input": {},  # input captured in tool turn below
                            }
                        ],
                    })

            elif role == "tool":
                # Tool result — must follow the assistant tool_use block
                tool_use_id = pending_tool_use_id or "unknown"
                converted.append({
                    "role": "user",
                    "content": [
                        {
                            "type": "tool_result",
                            "tool_use_id": tool_use_id,
                            "content": content,
                        }
                    ],
                })
                pending_tool_use_id = None

        return converted
