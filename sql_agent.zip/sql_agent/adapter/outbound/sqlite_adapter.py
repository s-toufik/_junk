"""
SQLite adapter — implements DatabasePort using the stdlib sqlite3 module.
"""
from __future__ import annotations
import sqlite3
from typing import Any

from sql_agent.application.port.outbound.ports import DatabasePort
from sql_agent.domain.model.models import (
    ColumnInfo,
    DatabaseSchema,
    QueryResult,
    TableSchema,
)


class SQLiteDatabaseAdapter(DatabasePort):
    def __init__(self, db_path: str) -> None:
        self._db_path = db_path

    # ------------------------------------------------------------------ #
    # DatabasePort                                                         #
    # ------------------------------------------------------------------ #
    def get_schema(self) -> DatabaseSchema:
        with self._connect() as conn:
            table_names = self._list_tables(conn)
            tables = tuple(self._describe_table(conn, name) for name in table_names)
        return DatabaseSchema(tables=tables)

    def execute_query(self, sql: str) -> QueryResult:
        with self._connect() as conn:
            cursor = conn.execute(sql)
            columns = tuple(d[0] for d in cursor.description or [])
            rows = tuple(tuple(row) for row in cursor.fetchall())
        row_count = len(rows)
        return QueryResult(
            columns=columns,
            rows=rows,
            row_count=row_count,
            truncated=False,  # LIMIT already enforced upstream
        )

    # ------------------------------------------------------------------ #
    # Private helpers                                                      #
    # ------------------------------------------------------------------ #
    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self._db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _list_tables(self, conn: sqlite3.Connection) -> list[str]:
        rows = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
        ).fetchall()
        return [r[0] for r in rows]

    def _describe_table(self, conn: sqlite3.Connection, table: str) -> TableSchema:
        pragma_rows = conn.execute(f"PRAGMA table_info('{table}')").fetchall()
        columns = tuple(
            ColumnInfo(
                name=row[1],
                type=row[2] or "TEXT",
                nullable=not row[3],
                primary_key=bool(row[5]),
            )
            for row in pragma_rows
        )
        fk_rows = conn.execute(f"PRAGMA foreign_key_list('{table}')").fetchall()
        foreign_keys = tuple(
            f"{row[3]} → {row[2]}.{row[4]}" for row in fk_rows
        )
        return TableSchema(name=table, columns=columns, foreign_keys=foreign_keys)
