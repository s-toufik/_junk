"""
CLI inbound adapter — drives the SQLAgentPort from the command line.
"""
from __future__ import annotations
import sys

from sql_agent.application.port.inbound.ports import SQLAgentPort


class CLIAdapter:
    def __init__(self, agent: SQLAgentPort) -> None:
        self._agent = agent

    def run_interactive(self) -> None:
        print("SQLAgent ready. Type your question (or 'quit' to exit).\n")
        while True:
            try:
                question = input("You: ").strip()
            except (EOFError, KeyboardInterrupt):
                print("\nBye.")
                break

            if not question:
                continue
            if question.lower() in {"quit", "exit", "q"}:
                print("Bye.")
                break

            answer = self._agent.run(question)
            print(f"\nAgent: {answer}\n")

    def run_single(self, question: str) -> str:
        return self._agent.run(question)
