# Agent Project

Production-grade LangChain + LangGraph agent using hexagonal (ports & adapters) architecture.

## Architecture

```
domain/          # Pure Python — zero framework imports
  entities/      # AgentResponse
  exceptions/    # Typed domain exceptions
  ports/         # AgentPort, GraphPort, ToolPort (ABCs)

application/     # AgentService — orchestrates via ports only

infrastructure/  # All framework code lives here
  llm/           # LLMProvider (LangChain/OpenAI)
  tools/         # OracleTool, PythonExecutorTool
  graph/         # AgentGraph (LangGraph)
  persistence/   # CheckpointerFactory (Postgres)

container.py     # Dependency injection wiring
main.py          # Entrypoint
```

## Setup

```bash
cp .env.example .env
# Fill in your values in .env

pip install -r requirements.txt

python main.py
```

## Run Tests

```bash
pytest tests/unit -v
```

## Key Design Decisions

- **Domain has zero framework imports** — ports are pure ABCs
- **GraphPort** decouples AgentService from LangGraph entirely
- **OracleTool** uses `oracledb.create_pool_async()` — one pool per process
- **PythonExecutorTool** runs code in a subprocess with a hard timeout — no `exec()`
- **AsyncPostgresSaver** persists conversation memory across restarts
- **Config** via `pydantic-settings` — loads from `.env`, no hardcoded secrets
- **Container** is the single wiring point — no cross-layer instantiation elsewhere
- Fully `async/await` throughout
