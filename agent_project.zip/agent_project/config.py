from pydantic_settings import BaseSettings, SettingsConfigDict


class Config(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8")

    # LLM
    llm_model: str = "gpt-4o"
    llm_api_key: str
    llm_base_url: str = "https://api.openai.com/v1"

    # Oracle DB
    oracle_user: str
    oracle_password: str
    oracle_dsn: str  # e.g. "localhost:1521/XEPDB1"
    oracle_pool_min: int = 2
    oracle_pool_max: int = 10

    # Postgres checkpointer (persistent memory)
    postgres_url: str  # e.g. "postgresql://user:pass@localhost/agent_db"

    # Python executor sandbox
    executor_timeout_seconds: int = 10
