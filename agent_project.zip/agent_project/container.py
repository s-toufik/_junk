"""
Dependency injection container — the only place where all layers are wired together.
Nothing else instantiates infrastructure classes directly.
"""
import logging
from config import Config
from infrastructure.llm.llm_provider import LLMProvider
from infrastructure.tools.oracle_tool import OracleTool
from infrastructure.tools.python_executor_tool import PythonExecutorTool
from infrastructure.persistence.checkpointer import CheckpointerFactory
from infrastructure.graph.agent_graph import AgentGraph
from application.agent_service import AgentService

logger = logging.getLogger(__name__)


class Container:
    def __init__(self, config: Config):
        self._config = config
        self._oracle_tool: OracleTool | None = None
        self._agent_service: AgentService | None = None

    async def start(self) -> "Container":
        config = self._config

        # LLM
        llm = LLMProvider(config).get_llm()

        # Tools — domain ports, adapted to LangChain
        self._oracle_tool = OracleTool(config)
        await self._oracle_tool.initialize()

        python_tool = PythonExecutorTool(config)

        lc_tools = [
            self._oracle_tool.as_langchain_tool(),
            python_tool.as_langchain_tool(),
        ]

        # Persistent checkpointer
        checkpointer = await CheckpointerFactory(config.postgres_url).create()

        # Graph (infrastructure) — injected into service via GraphPort
        graph = AgentGraph(llm=llm, tools=lc_tools, checkpointer=checkpointer)

        # Application service depends only on GraphPort abstraction
        self._agent_service = AgentService(graph=graph)

        logger.info("Container fully initialized.")
        return self

    async def stop(self) -> None:
        if self._oracle_tool:
            await self._oracle_tool.close()
        logger.info("Container shut down.")

    @property
    def agent_service(self) -> AgentService:
        if self._agent_service is None:
            raise RuntimeError("Container not started. Call await container.start().")
        return self._agent_service
