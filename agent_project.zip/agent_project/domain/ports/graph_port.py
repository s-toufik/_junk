from abc import ABC, abstractmethod
from domain.entities.agent_response import AgentResponse


class GraphPort(ABC):
    @abstractmethod
    async def invoke(self, user_input: str, session_id: str) -> AgentResponse:
        pass
