from abc import ABC, abstractmethod


class ToolPort(ABC):
    """
    Domain port for tools.
    Returns a plain callable — zero framework imports in domain.
    Infrastructure adapters wrap this into LangChain tools.
    """

    @abstractmethod
    def get_name(self) -> str:
        pass

    @abstractmethod
    def get_description(self) -> str:
        pass

    @abstractmethod
    async def execute(self, **kwargs) -> str:
        pass
