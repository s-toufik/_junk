class AgentException(Exception):
    """Base exception for the agent domain."""


class ToolExecutionError(AgentException):
    """Raised when a tool fails to execute."""

    def __init__(self, tool_name: str, reason: str):
        self.tool_name = tool_name
        self.reason = reason
        super().__init__(f"Tool '{tool_name}' failed: {reason}")


class DatabaseError(AgentException):
    """Raised when Oracle DB operations fail."""

    def __init__(self, reason: str):
        super().__init__(f"Database error: {reason}")


class CodeExecutionError(AgentException):
    """Raised when sandboxed Python execution fails."""

    def __init__(self, reason: str):
        super().__init__(f"Code execution error: {reason}")


class GraphInvocationError(AgentException):
    """Raised when the LangGraph agent graph fails."""

    def __init__(self, reason: str):
        super().__init__(f"Graph invocation error: {reason}")
