from dataclasses import dataclass


@dataclass(frozen=True)
class AgentResponse:
    content: str
    session_id: str
