import asyncio
import logging
import uuid
import sys
from config import Config
from container import Container

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s - %(message)s",
    stream=sys.stdout,
)
logger = logging.getLogger(__name__)


async def main() -> None:
    config = Config()
    container = Container(config)

    await container.start()
    try:
        session_id = str(uuid.uuid4())
        logger.info("Session started: %s", session_id)
        print("Agent ready. Type 'exit' to quit.\n")

        while True:
            user_input = input("You: ").strip()
            if user_input.lower() in ("exit", "quit"):
                break

            response = await container.agent_service.invoke(user_input, session_id)
            print(f"Agent: {response.content}\n")

    finally:
        await container.stop()


if __name__ == "__main__":
    asyncio.run(main())
