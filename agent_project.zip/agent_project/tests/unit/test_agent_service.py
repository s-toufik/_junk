import pytest
from unittest.mock import AsyncMock
from application.agent_service import AgentService
from domain.entities.agent_response import AgentResponse
from domain.exceptions.agent_exceptions import GraphInvocationError


@pytest.fixture
def mock_graph():
    return AsyncMock()


@pytest.fixture
def service(mock_graph):
    return AgentService(graph=mock_graph)


@pytest.mark.asyncio
async def test_invoke_returns_response(service, mock_graph):
    mock_graph.invoke.return_value = AgentResponse(
        content="Hello!", session_id="s1"
    )
    result = await service.invoke("Hi", "s1")
    assert result.content == "Hello!"
    mock_graph.invoke.assert_awaited_once_with("Hi", "s1")


@pytest.mark.asyncio
async def test_invoke_raises_on_empty_input(service):
    with pytest.raises(ValueError):
        await service.invoke("   ", "s1")


@pytest.mark.asyncio
async def test_invoke_wraps_unexpected_exception(service, mock_graph):
    mock_graph.invoke.side_effect = RuntimeError("boom")
    with pytest.raises(GraphInvocationError):
        await service.invoke("test", "s1")
