import pytest
from unittest.mock import MagicMock
from infrastructure.tools.python_executor_tool import PythonExecutorTool
from domain.exceptions.agent_exceptions import CodeExecutionError


@pytest.fixture
def tool():
    config = MagicMock()
    config.executor_timeout_seconds = 5
    return PythonExecutorTool(config)


@pytest.mark.asyncio
async def test_execute_simple_code(tool):
    result = await tool.execute("print('hello')")
    assert "hello" in result


@pytest.mark.asyncio
async def test_execute_returns_no_output_message(tool):
    result = await tool.execute("x = 1 + 1")
    assert "no output" in result.lower()


@pytest.mark.asyncio
async def test_execute_raises_on_bad_code(tool):
    with pytest.raises(CodeExecutionError):
        await tool.execute("raise ValueError('oops')")
