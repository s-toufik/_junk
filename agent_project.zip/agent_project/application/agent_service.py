import logging
from domain.ports.agent_port import AgentPort
from domain.ports.graph_port import GraphPort
from domain.entities.agent_response import AgentResponse
from domain.exceptions.agent_exceptions import GraphInvocationError

logger = logging.getLogger(__name__)


class AgentService(AgentPort):
    """
    Application layer: orchestrates the agent graph via the GraphPort abstraction.
    Has zero knowledge of LangChain, LangGraph, or any infrastructure detail.
    """

    def __init__(self, graph: GraphPort):
        self._graph = graph

    async def invoke(self, user_input: str, session_id: str) -> AgentResponse:
        if not user_input.strip():
            raise ValueError("user_input cannot be empty.")

        logger.info("AgentService.invoke", extra={"session_id": session_id})

        try:
            return await self._graph.invoke(user_input, session_id)
        except GraphInvocationError:
            raise
        except Exception as exc:
            logger.exception("Unexpected error in AgentService.invoke")
            raise GraphInvocationError(str(exc)) from exc
