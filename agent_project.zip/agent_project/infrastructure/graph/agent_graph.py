import logging
from typing import Annotated
from langchain_core.messages import BaseMessage
from langchain_openai import ChatOpenAI
from langgraph.graph import StateGraph, START
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode, tools_condition
from langgraph.checkpoint.base import BaseCheckpointSaver
from langchain_core.tools import BaseTool
from typing_extensions import TypedDict
from domain.ports.graph_port import GraphPort
from domain.entities.agent_response import AgentResponse
from domain.exceptions.agent_exceptions import GraphInvocationError

logger = logging.getLogger(__name__)


class AgentState(TypedDict):
    messages: Annotated[list[BaseMessage], add_messages]


class AgentGraph(GraphPort):
    """
    Infrastructure adapter that implements GraphPort using LangGraph.
    The application layer only sees GraphPort — never this class directly.
    """

    def __init__(
        self,
        llm: ChatOpenAI,
        tools: list[BaseTool],
        checkpointer: BaseCheckpointSaver,
    ):
        self._llm_with_tools = llm.bind_tools(tools)
        self._tools = tools
        self._checkpointer = checkpointer
        self._graph = self._build()

    def _build(self):
        builder = StateGraph(AgentState)

        builder.add_node("agent", self._agent_node)
        builder.add_node("tools", ToolNode(self._tools))

        builder.add_edge(START, "agent")
        builder.add_conditional_edges("agent", tools_condition)
        builder.add_edge("tools", "agent")

        return builder.compile(checkpointer=self._checkpointer)

    async def _agent_node(self, state: AgentState) -> AgentState:
        logger.debug("Agent node invoked with %d messages.", len(state["messages"]))
        response = await self._llm_with_tools.ainvoke(state["messages"])
        return {"messages": [response]}

    async def invoke(self, user_input: str, session_id: str) -> AgentResponse:
        config = {"configurable": {"thread_id": session_id}}
        try:
            result = await self._graph.ainvoke(
                {"messages": [{"role": "user", "content": user_input}]},
                config=config,
            )
            content = result["messages"][-1].content
            logger.info("Graph invocation complete.", extra={"session_id": session_id})
            return AgentResponse(content=content, session_id=session_id)
        except Exception as exc:
            logger.exception("Graph invocation failed.")
            raise GraphInvocationError(str(exc)) from exc
