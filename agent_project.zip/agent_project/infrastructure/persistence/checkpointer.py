import logging
from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver

logger = logging.getLogger(__name__)


class CheckpointerFactory:
    """
    Builds a persistent async Postgres checkpointer for LangGraph.
    Replaces in-process MemorySaver — survives restarts.
    """

    def __init__(self, postgres_url: str):
        self._postgres_url = postgres_url

    async def create(self) -> AsyncPostgresSaver:
        checkpointer = AsyncPostgresSaver.from_conn_string(self._postgres_url)
        await checkpointer.setup()  # creates tables if not exists
        logger.info("Postgres checkpointer ready.")
        return checkpointer
