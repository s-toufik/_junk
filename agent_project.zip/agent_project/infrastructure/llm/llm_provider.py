import httpx
from langchain_openai import ChatOpenAI
from config import Config


class LLMProvider:
    def __init__(self, config: Config):
        self._llm = ChatOpenAI(
            model=config.llm_model,
            api_key=config.llm_api_key,
            base_url=config.llm_base_url,
            http_client=httpx.AsyncClient(),  # async client for async usage
        )

    def get_llm(self) -> ChatOpenAI:
        return self._llm
