import asyncio
import logging
import textwrap
from langchain_core.tools import StructuredTool
from pydantic import BaseModel, Field
from domain.ports.tool_port import ToolPort
from domain.exceptions.agent_exceptions import CodeExecutionError
from config import Config

logger = logging.getLogger(__name__)


class PythonCodeInput(BaseModel):
    code: str = Field(description="Valid Python code to execute.")


class PythonExecutorTool(ToolPort):
    """
    Sandboxed Python executor using a subprocess with a strict timeout.
    No raw exec() — code runs in an isolated child process.
    """

    def __init__(self, config: Config):
        self._timeout = config.executor_timeout_seconds

    def get_name(self) -> str:
        return "execute_python_code"

    def get_description(self) -> str:
        return (
            "Create and execute Python code in a sandboxed subprocess. "
            "Use for computations, data transformations, or logic requiring code. "
            "Returns stdout output or error messages."
        )

    async def execute(self, code: str) -> str:  # type: ignore[override]
        """Runs code in a subprocess with a timeout. No exec() on the main process."""
        wrapped = textwrap.dedent(f"""
import sys
try:
{textwrap.indent(code, '    ')}
except Exception as e:
    print(f"RuntimeError: {{e}}", file=sys.stderr)
""")
        try:
            proc = await asyncio.create_subprocess_exec(
                "python3", "-c", wrapped,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(), timeout=self._timeout
            )

            if proc.returncode != 0:
                err = stderr.decode().strip()
                logger.warning("Python executor stderr: %s", err)
                raise CodeExecutionError(err)

            output = stdout.decode().strip()
            logger.info("Python executor succeeded.")
            return output or "Code executed successfully with no output."

        except asyncio.TimeoutError:
            proc.kill()
            raise CodeExecutionError(
                f"Execution timed out after {self._timeout}s."
            )
        except CodeExecutionError:
            raise
        except Exception as exc:
            raise CodeExecutionError(str(exc)) from exc

    def as_langchain_tool(self) -> StructuredTool:
        execute_fn = self.execute
        return StructuredTool.from_function(
            coroutine=execute_fn,
            name=self.get_name(),
            description=self.get_description(),
            args_schema=PythonCodeInput,
        )
