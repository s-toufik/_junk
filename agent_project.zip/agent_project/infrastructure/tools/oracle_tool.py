import logging
import oracledb
from langchain_core.tools import StructuredTool
from pydantic import BaseModel, Field
from domain.ports.tool_port import ToolPort
from domain.exceptions.agent_exceptions import DatabaseError
from config import Config

logger = logging.getLogger(__name__)


class OracleSQLInput(BaseModel):
    query: str = Field(description="A valid SQL statement to execute against Oracle DB.")


class OracleTool(ToolPort):
    """
    Infrastructure adapter: wraps Oracle DB access as a domain ToolPort.
    Uses a connection pool — one pool shared for the process lifetime.
    """

    def __init__(self, config: Config):
        self._pool: oracledb.AsyncConnectionPool | None = None
        self._config = config

    async def initialize(self) -> None:
        """Call once at startup to create the connection pool."""
        self._pool = await oracledb.create_pool_async(
            user=self._config.oracle_user,
            password=self._config.oracle_password,
            dsn=self._config.oracle_dsn,
            min=self._config.oracle_pool_min,
            max=self._config.oracle_pool_max,
        )
        logger.info("Oracle connection pool initialized.")

    async def close(self) -> None:
        if self._pool:
            await self._pool.close()
            logger.info("Oracle connection pool closed.")

    def get_name(self) -> str:
        return "execute_oracle_sql"

    def get_description(self) -> str:
        return (
            "Connect to an Oracle database and execute a SQL query. "
            "Use when you need to query or manipulate data in Oracle DB. "
            "Input must be a valid SQL statement."
        )

    async def execute(self, query: str) -> str:  # type: ignore[override]
        if self._pool is None:
            raise DatabaseError("Connection pool not initialized.")
        try:
            async with self._pool.acquire() as conn:
                async with conn.cursor() as cursor:
                    await cursor.execute(query)
                    if cursor.description:
                        columns = [col[0] for col in cursor.description]
                        rows = await cursor.fetchall()
                        result = [dict(zip(columns, row)) for row in rows]
                        logger.info("Oracle query returned %d rows.", len(result))
                        return str(result)
                    await conn.commit()
                    return f"Query executed. Rows affected: {cursor.rowcount}"
        except DatabaseError:
            raise
        except Exception as exc:
            logger.exception("Oracle execution error.")
            raise DatabaseError(str(exc)) from exc

    def as_langchain_tool(self) -> StructuredTool:
        """Adapts the domain port into a LangChain-compatible tool."""
        execute_fn = self.execute
        return StructuredTool.from_function(
            coroutine=execute_fn,
            name=self.get_name(),
            description=self.get_description(),
            args_schema=OracleSQLInput,
        )
